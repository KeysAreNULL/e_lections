@extends('layouts.app')

@section('title', 'Election Results')

@section('content')
    @if (session('success'))
        <p class="text-green-400 font-semibold mb-4">{{ session('success') }}</p>
    @endif

    <div class="container mx-auto px-4">
        <div class="section-block">
            <h2 class="text-2xl font-bold mb-6 text-yellow-400">{{ $election->title }} — Results</h2>

            {{-- Winners Table --}}
            <div class="section-block mb-8 overflow-x-auto">
                <h3 class="text-lg font-semibold text-white mb-2">Winners</h3>
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="border-b border-gray-600">
                            <th class="px-4 py-2 text-white">Position</th>
                            <th class="px-4 py-2 text-white">Winner(s)</th>
                            <th class="px-4 py-2 text-white">Total Votes</th>
                            <th class="px-4 py-2 text-white">Max Winners</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($positions as $position)
                            @php
                                $r = $results[$position] ?? [
                                    'winners' => [],
                                    'total_votes' => 0,
                                    'max_winners' => 1,
                                    'isTie' => false,
                                ];
                            @endphp
                            <tr
                                class="border-b border-gray-600 {{ empty($r['winners']) ? 'text-gray-400' : ($r['isTie'] ? 'bg-red-700' : '') }}">
                                <td class="px-4 py-2 text-white">{{ $position }}</td>
                                <td class="px-4 py-2 text-white">
                                    @if (count($r['winners']))
                                        {{ implode(', ', $r['winners']) }}
                                        @if ($r['isTie'])
                                            <span class="italic text-yellow-300 ml-2">(Tie)</span>
                                        @endif
                                    @else
                                        <span class="italic text-gray-400">No votes yet</span>
                                    @endif
                                </td>
                                <td class="px-4 py-2 text-white">{{ $r['total_votes'] }}</td>
                                <td class="px-4 py-2 text-white">{{ $r['max_winners'] }}</td>
                            </tr>
                        @endforeach

                    </tbody>
                </table>
            </div>


            {{-- Charts --}}
            @foreach ($positions as $position)
                <div class="mb-12">
                    <h3 class="text-xl font-semibold mb-4 text-white">{{ $position }}</h3>
                    <div class="grid grid-cols-1 md:grid-cols-{{ $election->department == 'General' ? '3' : '1' }} gap-6">
                        @isset($chartsData[$position]['stacked'])
                            <div class="section-block p-4 rounded shadow flex flex-col" style="min-height: 400px;">
                                <h4 class="text-lg font-semibold text-white mb-2">Voters Distribution</h4>
                                <div class="flex-1">
                                    <canvas id="stacked-{{ \Illuminate\Support\Str::slug($position) }}"></canvas>
                                </div>
                            </div>
                        @endisset

                        @if ($election->department == 'General' && isset($chartsData[$position]['votesPie']))
                            <div class="section-block p-4 rounded shadow">
                                <h4 class="text-lg font-semibold text-white mb-2">Votes per Department</h4>
                                <canvas id="votesPie-{{ \Illuminate\Support\Str::slug($position) }}"></canvas>
                            </div>
                        @endif

                        @if ($election->department == 'General' && isset($chartsData[$position]['nonVotersPie']))
                            <div class="section-block p-4 rounded shadow">
                                <h4 class="text-lg font-semibold text-white mb-2">Non-Voters per Department</h4>
                                <canvas id="nonVotersPie-{{ \Illuminate\Support\Str::slug($position) }}"></canvas>
                            </div>
                        @endif

                        @if (strtolower($election->department) !== 'general' && isset($chartsData[$position]['deptTurnoutPie']))
                            <div class="section-block p-4 rounded shadow">
                                <h4 class="text-lg font-semibold text-white mb-2">Department Voter Turnout</h4>
                                <canvas id="deptTurnoutPie-{{ \Illuminate\Support\Str::slug($position) }}"></canvas>
                            </div>
                        @endif
                    </div>
                </div>
            @endforeach

            <a href="{{ route('results') }}" class="btn btn-warning mt-4">Back to Elections</a>

            @if ($election->is_validated)
            @else
                <p class="italic text-gray-400">Results are hidden until the election is validated.</p>
            @endif

            {{-- ✅ Validation Button --}}
            @php
                $canValidate = in_array(session('role'), ['Comelec Head']);
            @endphp
            @php
                $now = now();
                $start = \Carbon\Carbon::parse($election->start_time);
                $end = \Carbon\Carbon::parse($election->end_time);
                $status = $now->lt($start) ? 'upcoming' : ($now->between($start, $end) ? 'ongoing' : 'ended');
            @endphp



            @if (in_array(session('role'), ['Comelec Head']) && $status === 'ended')
                <form action="{{ route('elections.validate', $election->election_id) }}" method="POST" class="mt-3">
                    @csrf
                    <button type="submit" class="btn {{ $election->is_validated ? 'btn-warning' : 'btn-save' }}">
                        {{ $election->is_validated ? 'Hide Results' : 'Validate Results' }}
                    </button>
                </form>
            @endif


        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const whiteOptions = {
                color: '#FFFFFF',
                ticks: {
                    color: '#FFFFFF'
                },
                grid: {
                    color: 'rgba(255,255,255,0.2)'
                }
            };

            @foreach ($positions as $position)
                @php $charts = $chartsData[$position] ?? [] @endphp
                @if (!empty($charts['stacked']))
                    new Chart(document.getElementById('stacked-{{ \Illuminate\Support\Str::slug($position) }}')
                        .getContext('2d'), {
                            type: 'bar',
                            data: @json($charts['stacked']),
                            options: {
                                responsive: true,
                                maintainAspectRatio: false,
                                plugins: {
                                    legend: {
                                        labels: {
                                            color: '#FFFFFF'
                                        },
                                        position: 'bottom'
                                    }
                                },
                                scales: {
                                    x: {
                                        ...whiteOptions,
                                        stacked: true
                                    },
                                    y: {
                                        ...whiteOptions,
                                        stacked: true,
                                        beginAtZero: true
                                    }
                                }
                            }
                        });
                @endif

                @if (!empty($charts['votesPie']) && $election->department == 'General')
                    new Chart(document.getElementById('votesPie-{{ \Illuminate\Support\Str::slug($position) }}')
                        .getContext('2d'), {
                            type: 'pie',
                            data: @json($charts['votesPie']),
                            options: {
                                responsive: true,
                                maintainAspectRatio: true,
                                plugins: {
                                    legend: {
                                        labels: {
                                            color: '#FFFFFF'
                                        },
                                        position: 'bottom'
                                    }
                                }
                            }
                        });
                @endif

                @if (!empty($charts['nonVotersPie']) && $election->department == 'General')
                    new Chart(document.getElementById(
                        'nonVotersPie-{{ \Illuminate\Support\Str::slug($position) }}').getContext('2d'), {
                        type: 'pie',
                        data: @json($charts['nonVotersPie']),
                        options: {
                            responsive: true,
                            maintainAspectRatio: true,
                            plugins: {
                                legend: {
                                    labels: {
                                        color: '#FFFFFF'
                                    },
                                    position: 'bottom'
                                }
                            }
                        }
                    });
                @endif

                @if (!empty($charts['deptTurnoutPie']) && strtolower($election->department) !== 'general')
                    new Chart(document.getElementById(
                        'deptTurnoutPie-{{ \Illuminate\Support\Str::slug($position) }}').getContext(
                        '2d'), {
                        type: 'pie',
                        data: @json($charts['deptTurnoutPie']),
                        options: {
                            responsive: true,
                            maintainAspectRatio: true,
                            plugins: {
                                legend: {
                                    labels: {
                                        color: '#FFFFFF'
                                    },
                                    position: 'bottom'
                                }
                            }
                        }
                    });
                @endif
            @endforeach
        });
    </script>
@endsection
