<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Candidate extends Model
{
    use HasFactory;

    protected $table = 'candidates';
    protected $primaryKey = 'candidate_id';
    public $timestamps = false;

    protected $fillable = [
        'election_id',
        'id_number',   // Foreign key to student.id_number
        'name',
        'position',
        'partylist',
        'photo',
    ];

    /**
     * Link to the election this candidate belongs to.
     */
    public function election()
    {
        return $this->belongsTo(Election::class, 'election_id', 'election_id');
    }

    /**
     * Link to the student who is the candidate.
     * Uses the id_number on both models.
     */
    public function student()
    {
        return $this->belongsTo(Student::class, 'id_number', 'id_number');
    }
}
