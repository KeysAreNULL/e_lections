<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Election;
use Carbon\Carbon;

class ElectionController extends Controller
{
    private array $positionsList = [
        'President',
        'Vice President',
        'Executive Secretary',
        'Finance Chairman',
        'Councilor for Academics and Research',
        'Councilor for External Affairs',
        'Councilor for Spiritual Development',
        'Councilor for Athletics and Recreation',
        'Councilor for Student Welfare and Development',
    ];

    private ?string $facultyDept = null;

    private function facultyDeptForSession(?string $idNumber): ?string
    {
        if ($this->facultyDept !== null)
            return $this->facultyDept;

        return $this->facultyDept = $idNumber
            ? DB::table('faculty')->where('id_number', $idNumber)->value('department')
            : null;
    }

    private function canManageDepartment(?string $dept): bool
    {
        $role = session('role');
        $idNumber = session('id_number');

        if (in_array($role, ['Comelec Head', 'Student Services Office Head']))
            return true;

        if ($role === 'admin')
            return $this->facultyDeptForSession($idNumber) === $dept;

        return false;
    }

    public function index()
    {
        $role = session('role');
        $idNumber = session('id_number');

        if (!$role || !$idNumber) {
            return redirect()->route('login')->withErrors(['auth' => 'Login required.']);
        }

        $departments = DB::table('student')
            ->whereNotNull('department')
            ->where('department', '!=', '')
            ->distinct()
            ->pluck('department');

        $facultyDept = $this->facultyDeptForSession($idNumber);

        $availableDepartments = match ($role) {
            'Comelec Head', 'Student Services Office Head' => $departments->prepend('General')->values(),
            'admin' => collect([$facultyDept]),
            default => $facultyDept ? collect([$facultyDept]) : collect([]),
        };

        // Base positions
        $positionsList = $this->positionsList;

        // Remove "President" if the user is admin
        if ($role === 'admin') {
            $positionsList = array_filter($positionsList, fn($p) => $p !== 'President');
        }

        // Add "Governor" per department if the user is Comelec Head, skipping 'General'
        if ($role === 'Comelec Head') {
            foreach ($availableDepartments as $dept) {
                if (strtolower($dept) !== 'general') {
                    $positionsList[] = "Governor ($dept)";
                }
            }
        }

        $query = Election::with('candidates')->orderBy('start_time', 'desc');

        if (!in_array($role, ['Comelec Head', 'Student Services Office Head'])) {
            $facultyDept ? $query->where('department', $facultyDept) : $query->whereRaw('0=1');
        }

        $elections = $query->get();

        return view('schedule_election', [
            'departments' => $availableDepartments,
            'elections' => $elections,
            'positionsList' => $positionsList,
        ]);
    }



    public function store(Request $request)
    {
        $facultyDept = $this->facultyDeptForSession(session('id_number'));

        $request->validate([
            'title' => 'required|string|max:255',
            'start_time' => 'required|date',
            'end_time' => 'required|date|after:start_time',
            'department' => 'nullable|string|max:255',
            'positions' => 'array',
            'positions.*' => 'string',
            'custom_positions' => 'nullable|string',
        ]);

        $dept = $request->department ?: $facultyDept;

        if (!$this->canManageDepartment($dept))
            return back()->withErrors(['error' => 'Unauthorized for this department.']);

        // Positions list from checkboxes
        $positions = $request->positions ?? [];

        // Max winner map (clean)
        $maxWinners = [];

        // Parse custom positions
        if ($request->filled('custom_positions')) {

            $items = array_filter(array_map('trim', explode(',', $request->custom_positions)));

            foreach ($items as $item) {

                // "Position - 2" or "Position"
                $parts = array_map('trim', explode('-', $item, 2));
                $name = $parts[0];
                $num = isset($parts[1]) && is_numeric($parts[1]) ? intval($parts[1]) : 1;

                if (!in_array($name, $positions)) {
                    $positions[] = $name;
                }

                $maxWinners[$name] = $num;
            }
        }

        // Now default max_winners for ALL positions
        foreach ($positions as $pos) {
            if (!isset($maxWinners[$pos])) {
                $maxWinners[$pos] = 1;   // 🔥 Default here, no form needed
            }
        }

        // Save as clean JSON
        Election::create([
            'title' => $request->title,
            'start_time' => $request->start_time,
            'end_time' => $request->end_time,
            'department' => $dept ?: 'General',
            'positions' => json_encode(array_values($positions)),
            'max_winners' => json_encode($maxWinners),
        ]);

        return redirect()->route('elections.index')
            ->with('success', 'Election created successfully!');
    }


    public function update(Request $request, $id)
    {
        $election = Election::findOrFail($id);

        // Basic fields
        $election->title = $request->title;
        $election->start_time = $request->start_time;
        $election->end_time = $request->end_time;
        $election->department = $request->department;

        // Positions: merge checkboxes and custom positions
        $positions = $request->input('positions', []);
        $customPositions = $request->input('custom_positions', '');
        if (!empty($customPositions)) {
            $customPositionsArr = array_map('trim', explode(',', $customPositions));
            $positions = array_merge($positions, $customPositionsArr);
        }

        // Remove empty strings
        $positions = array_filter($positions, fn($p) => $p !== '');

        // Save positions as JSON
        $election->positions = json_encode(array_values($positions));

        // Max winners: ensure array, default to 1 if missing
        $maxWinnersInput = $request->input('max_winners', []);
        $maxWinners = [];
        foreach ($positions as $pos) {
            $maxWinners[$pos] = isset($maxWinnersInput[$pos]) && (int) $maxWinnersInput[$pos] > 0
                ? (int) $maxWinnersInput[$pos]
                : 1;
        }
        $election->max_winners = json_encode($maxWinners);

        $election->save();

        return redirect()->back()->with('success', 'Election updated successfully.');
    }


    public function destroy($id)
    {
        $election = Election::findOrFail($id);

        if (!$this->canManageDepartment($election->department))
            return back()->withErrors(['error' => 'Unauthorized.']);
        if ($this->hasStarted($election))
            return back()->withErrors(['error' => 'Election already started.']);

        $election->delete();

        return redirect()->route('elections.index')->with('success', 'Election deleted successfully.');
    }

    private function hasStarted(Election $election): bool
    {
        return Carbon::parse($election->start_time, config('app.timezone'))->isPast();
    }

}