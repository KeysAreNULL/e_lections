<script>
    window.location.href = "/login";
</script>
<?php /**PATH C:\xampp\htdocs\test_app\resources\views\welcome.blade.php ENDPATH**/ ?>