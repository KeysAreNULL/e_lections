

<?php $__env->startSection('title', 'Voting Window'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container section-block">
        <h3 class="text-yellow-400 text-2xl font-bold mb-4">Voting Window</h3>
        <p>Welcome, Voter. Please select an active election to participate in.</p>

        <!-- 🗳 Election Select -->
        <form method="POST" action="<?php echo e(route('voting.select')); ?>" id="electionSelectForm">
            <?php echo csrf_field(); ?>
            <label class="font-semibold">Select Election:</label><br>
            <select name="select_election" onchange="this.form.submit()" class="input mb-4">
                <option value="">-- Choose an Election --</option>
                <?php $__currentLoopData = $elections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $election): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($election->election_id); ?>"
                        <?php echo e($selectedElection == $election->election_id ? 'selected' : ''); ?>>
                        <?php echo e($election->title); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </form>

        <?php if($selectedElection): ?>
            <?php if(!$isValid): ?>
                <p class="text-red-400 font-semibold mt-4">This election is not currently active.</p>
            <?php elseif($hasVoted): ?>
                <p class="text-green-400 font-semibold mt-4">You have already voted in this election. Thank you for
                    participating.</p>
            <?php else: ?>
                <!-- ✅ Ballot -->
                <form method="POST" action="<?php echo e(route('voting.submit')); ?>" id="votingForm">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="select_election" value="<?php echo e($selectedElection); ?>">

                    <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position => $candidates): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            // max winners for this position (provided by controller)
                            $max = $maxWinners[$position] ?? 1;
                            $isMulti = intval($max) > 1;
                            // sanitized name for HTML (keeps original in data attributes)
                            $inputName = $selectedElection . '__' . $position . ($isMulti ? '[]' : '');
                            $groupKey = $selectedElection . '__' . $position;
                        ?>

                        <div class="mt-8 mb-6">
                            <h4 class="text-xl font-bold text-white mb-3 border-b border-gray-600 pb-1">
                                <?php echo e(strtoupper($position)); ?>

                                <?php if($isMulti): ?>
                                    <span class="text-sm text-gray-400"> — choose up to <?php echo e($max); ?></span>
                                <?php endif; ?>
                            </h4>

                            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 position-group"
                                data-group="<?php echo e($groupKey); ?>" data-max="<?php echo e($max); ?>">
                                <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label
                                        class="candidate-card cursor-pointer bg-gray-800 p-4 rounded-2xl hover:bg-gray-700 transition flex flex-col items-center text-center shadow-md border-2 border-transparent"
                                        data-group="<?php echo e($groupKey); ?>">
                                        <?php if($isMulti): ?>
                                            <input type="checkbox" class="hidden ballot-choice" name="<?php echo e($inputName); ?>"
                                                value="<?php echo e($candidate->candidate_id); ?>">
                                        <?php else: ?>
                                            <input type="radio" class="hidden ballot-choice"
                                                name="<?php echo e($selectedElection); ?>__<?php echo e($position); ?>"
                                                value="<?php echo e($candidate->candidate_id); ?>">
                                        <?php endif; ?>

                                        <img src="<?php echo e($candidate->photo ? 'data:image/jpeg;base64,' . base64_encode($candidate->photo) : asset('assets/images/default.png')); ?>"
                                            alt="Candidate Photo"
                                            class="h-32 w-32 object-cover rounded-xl mb-3 border-4 border-transparent transition">
                                        <strong class="text-lg text-yellow-300"><?php echo e($candidate->name); ?></strong>
                                        <em class="text-gray-400 text-sm"><?php echo e($candidate->partylist); ?></em>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="text-center mt-8">
                        <button type="button" id="submitVotesBtn"
                            class="btn btn-save text-lg px-8 py-3 bg-yellow-500 hover:bg-yellow-400 text-black font-semibold rounded-lg transition">
                            Submit Votes
                        </button>
                    </div>
                </form>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <!-- Confirmation Modal -->
    <div id="confirmVoteModal" class="fixed inset-0 bg-black/30 backdrop-blur-sm hidden items-center justify-center z-50">
        <div class="bg-gray-800/90 p-6 rounded-xl shadow-xl w-96">
            <h2 class="text-xl font-bold mb-4 text-white">Confirm Your Votes</h2>
            <p class="text-gray-300 mb-6">Are you sure you want to submit your votes? You won’t be able to change them
                afterward.</p>
            <div class="flex justify-end space-x-3">
                <button id="cancelVoteBtn"
                    class="px-4 py-2 bg-gray-600/80 hover:bg-gray-700/80 text-white rounded-lg">Cancel</button>
                <button id="confirmVoteBtn"
                    class="px-4 py-2 bg-yellow-500 hover:bg-yellow-400 text-black rounded-lg font-semibold">Confirm</button>
            </div>
        </div>
    </div>

    <!-- JS: Confirmation Modal Logic -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const submitBtn = document.getElementById('submitVotesBtn');
            const modal = document.getElementById('confirmVoteModal');
            const cancelBtn = document.getElementById('cancelVoteBtn');
            const confirmBtn = document.getElementById('confirmVoteBtn');
            const form = document.getElementById('votingForm');

            submitBtn.addEventListener('click', () => {
                modal.classList.remove('hidden');
                modal.classList.add('flex');
            });

            cancelBtn.addEventListener('click', () => {
                modal.classList.add('hidden');
                modal.classList.remove('flex');
            });

            confirmBtn.addEventListener('click', () => {
                modal.classList.add('hidden');
                modal.classList.remove('flex');
                if (form) form.submit();
            });

            // Optional: close modal on clicking outside
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.classList.add('hidden');
                    modal.classList.remove('flex');
                }
            });
        });
    </script>

    <!-- 🧠 Smart Cache & UX Scripts -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('votingForm');
            if (!form) return;

            const EID = '<?php echo e($selectedElection); ?>';
            const CACHE_KEY = 'voteProgress_' + EID;
            let savedVotes = JSON.parse(localStorage.getItem(CACHE_KEY) || '{}');

            // Helper: get elements for a group
            const groupElems = (groupKey) => Array.from(document.querySelectorAll(
                `.position-group[data-group="${groupKey}"] .candidate-card`));

            // Restore saved choices visually
            Object.keys(savedVotes).forEach(key => {
                const val = savedVotes[key];
                if (Array.isArray(val)) {
                    // multi
                    val.forEach(v => {
                        const input = document.querySelector(
                            `input[name="${key}[]"][value="${v}"]`);
                        if (input) {
                            input.checked = true;
                            input.closest('.candidate-card').classList.add('selected');
                        }
                    });
                } else {
                    // single
                    const input = document.querySelector(`input[name="${key}"][value="${val}"]`);
                    if (input) {
                        input.checked = true;
                        input.closest('.candidate-card').classList.add('selected');
                    }
                }
            });

            // Attach handlers to all candidate cards
            document.querySelectorAll('.candidate-card').forEach(card => {
                card.addEventListener('click', (e) => {
                    // prevent double fire
                    const input = card.querySelector('input');
                    if (!input) return;

                    // derive group info
                    const group = card.dataset.group; // e.g. "3__President"
                    // find parent .position-group to read max
                    const groupContainer = document.querySelector(
                        `.position-group[data-group="${group}"]`);
                    const max = parseInt(groupContainer?.dataset.max ?? '1', 10);

                    const inputName = input.name; // if checkbox, name ends with []
                    if (input.type === 'radio') {
                        // clear visuals for group
                        document.querySelectorAll(`.candidate-card[data-group="${group}"]`).forEach(
                            c => c.classList.remove('selected'));
                        card.classList.add('selected');
                        input.checked = true;
                        // persist single value
                        savedVotes[group] = input.value;
                    } else if (input.type === 'checkbox') {
                        // toggle current
                        const currentlyChecked = !!input.checked;
                        // We'll toggle manually to ensure visual state is in sync
                        if (currentlyChecked) {
                            // was checked -> uncheck
                            input.checked = false;
                            card.classList.remove('selected');
                        } else {
                            // was unchecked -> enforce max
                            const alreadyChecked = Array.from(document.querySelectorAll(
                                `input[name="${input.name}"]`)).filter(i => i.checked).length;
                            if (alreadyChecked >= max) {
                                // quick flash warning
                                card.classList.add('shake');
                                setTimeout(() => card.classList.remove('shake'), 400);
                                return; // don't allow more
                            }
                            input.checked = true;
                            card.classList.add('selected');
                        }

                        // persist array of values for this group (strip trailing [] from name when storing)
                        const key = input.name.replace(/\[\]$/, '');
                        const checkedVals = Array.from(document.querySelectorAll(
                                `input[name="${input.name}"]`))
                            .filter(i => i.checked).map(i => i.value);

                        savedVotes[key] = checkedVals;
                    }

                    // update storage
                    localStorage.setItem(CACHE_KEY, JSON.stringify(savedVotes));
                });
            });

            // Clear cache after submitting
            form.addEventListener('submit', () => {
                localStorage.removeItem(CACHE_KEY);
            });

            // small CSS-injected shake for hitting limit
            const style = document.createElement('style');
            style.innerHTML = `
                .candidate-card.shake { animation: shake .38s; }
                @keyframes shake {
                    10%, 90% { transform: translateX(-1px); }
                    20%, 80% { transform: translateX(2px); }
                    30%, 50%, 70% { transform: translateX(-4px); }
                    40%, 60% { transform: translateX(4px); }
                }
            `;
            document.head.appendChild(style);
        });
    </script>

    <!-- 🧩 Styles for selection -->
    <style>
        .candidate-card.selected {
            background-color: #facc15 !important;
            color: #000 !important;
            border-color: #fbbf24 !important;
            transform: scale(1.02);
            transition: all 0.2s ease-in-out;
        }

        .candidate-card.selected strong {
            color: #000 !important;
        }

        .candidate-card.selected em {
            color: #1e1e1e !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\test_app\resources\views\voting_window.blade.php ENDPATH**/ ?>