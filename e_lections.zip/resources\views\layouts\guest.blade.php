{{-- resources/views/layouts/guest.blade.php --}}
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>@yield('title', 'CPAC E-lections')</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>

<body class="font-sans bg-black text-white min-h-screen relative">

    <!-- Background Video & Overlay -->
     <div class="background-overlay"></div>
    <div class="background-wrapper absolute inset-0 z-0">
        <img src="{{ asset('videos/background.jpg') }}" alt="Background" class="w-full h-full object-cover">
    </div>

    <!-- Content Wrapper -->
    <div class="relative z-20 flex flex-col min-h-screen">
        @include('partials.header')

        <main class="flex-1 flex items-center justify-center p-6">
            @yield('content')
        </main>

        @include('partials.footer')
    </div>

</body>

</html>
