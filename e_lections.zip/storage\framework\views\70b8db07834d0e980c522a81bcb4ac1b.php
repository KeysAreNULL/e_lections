<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title', 'My App'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">

</head>

<body class="font-sans bg-black text-white min-h-screen relative">


    <!-- ✅ Background Image & Blue Overlay -->
    <div class="background-overlay"></div>
    <div class="background-wrapper absolute inset-0 z-0">
        <img src="<?php echo e(asset('videos/background.jpg')); ?>" alt="Background" class="w-full h-full object-cover">
    </div>

    <!-- Main wrapper -->
    <div class="relative z-20 flex flex-col min-h-screen">
        <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- Main layout body -->
        <div class="flex flex-1 mt-16">

            <!-- Sidebar (hidden on login/register routes) -->
            <?php if(!Request::is('login') && !Request::is('register')): ?>
                <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?>

            <!-- Main content -->
            <main class="flex-1 p-6 mx-auto max-w-7xl min-w-[300px] md:ml-64">
                <?php echo $__env->yieldContent('content'); ?>
            </main>

        </div>

        

    </div>

    <script>
        const toggleBtn = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');

        toggleBtn?.addEventListener('click', () => {
            sidebar?.classList.toggle('hidden');
        });
    </script>

    <script>
        // Kill Back-Forward Cache resurrection
        window.addEventListener("pageshow", function(event) {
            if (event.persisted) {
                window.location.reload();
            }
        });

        // If user is logged out (no session flag), force redirect
        document.addEventListener("DOMContentLoaded", () => {
            const isLoggedIn = sessionStorage.getItem("loggedIn");
            const isLoginPage = window.location.pathname.includes("login");
            if (!isLoggedIn && !isLoginPage) {
                window.location.replace("/login");
            }
        });
    </script>

    <?php if(session('setLoggedIn')): ?>
        <script>
            sessionStorage.setItem("loggedIn", "true");
        </script>
    <?php endif; ?>


</body>

</html>
<?php /**PATH C:\xampp\htdocs\test_app\resources\views/layouts/app.blade.php ENDPATH**/ ?>