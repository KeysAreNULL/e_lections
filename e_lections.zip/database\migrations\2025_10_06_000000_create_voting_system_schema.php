<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up(): void
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        // PEOPLE
        Schema::create('people', function (Blueprint $table) {
            $table->unsignedInteger('person_id')->primary();
            $table->string('full_name', 100)->nullable();
            $table->enum('gender', ['male', 'female'])->nullable();
            $table->date('birth_date')->nullable();
            $table->string('contact_number', 20)->nullable();
            $table->string('address', 225)->nullable();
            $table->string('email', 100)->nullable();
        });

        // STUDENTS
        Schema::create('student', function (Blueprint $table) {
            $table->string('id_number', 25)->primary();
            $table->unsignedInteger('person_id')->nullable();
            $table->integer('year_level')->nullable();
            $table->string('course_or_strand', 50)->nullable();
            $table->string('department', 50)->nullable();
            $table->timestamps();

            $table->foreign('person_id')->references('person_id')->on('people')->cascadeOnDelete();
        });

        // FACULTY
        Schema::create('faculty', function (Blueprint $table) {
            $table->string('id_number', 25)->primary();
            $table->unsignedInteger('person_id')->nullable();
            $table->string('department', 50)->nullable();
            $table->string('position', 50)->nullable();
            $table->timestamps();

            $table->foreign('person_id')->references('person_id')->on('people')->cascadeOnDelete();
        });

        // USERS
        Schema::create('users', function (Blueprint $table) {
            $table->id('user_id');
            $table->unsignedInteger('person_id')->nullable();
            $table->string('id_number', 25)->unique()->nullable();
            $table->string('email', 100)->nullable();
            $table->enum('role', ['voter', 'ComElec'])->nullable();
            $table->timestamps();

            $table->foreign('person_id')->references('person_id')->on('people')->cascadeOnDelete();
        });

        // USER OTPS
        Schema::create('user_otps', function (Blueprint $table) {
            $table->integerIncrements('otp_id', )->primary();
            $table->string('id_number', 25);
            $table->string('otp_code', 6)->nullable();
            $table->timestamp('otp_timestamp')->useCurrent()->nullable();
            $table->dateTime('otp_expiry');
            $table->foreign('id_number')->references('id_number')->on('users')->cascadeOnDelete();
        });


        // ELECTIONS
        Schema::create('elections', function (Blueprint $table) {
            $table->increments('election_id');
            $table->string('title', 50);
            $table->timestamp('start_time')->useCurrent();
            $table->timestamp('end_time')->nullable();
            $table->string('department', 50)->default('General');
            $table->json('positions');                 // JSON array of position names
            $table->json('max_winners')->nullable();   // JSON array of max winners per position
            $table->boolean('is_validated')->default(false);  // election results hidden until validated
        });


        // CANDIDATES
        Schema::create('candidates', function (Blueprint $table) {
            $table->increments('candidate_id');
            $table->unsignedInteger('election_id')->nullable();
            $table->string('id_number', 25)->nullable();
            $table->string('name', 100)->nullable();
            $table->string('position', 50)->nullable();
            $table->string('partylist', 50)->nullable();

            $table->foreign('election_id')->references('election_id')->on('elections')->cascadeOnDelete();
            $table->foreign('id_number')->references('id_number')->on('student')->cascadeOnDelete();
        });

        // Add photo column
        DB::statement('ALTER TABLE candidates ADD photo LONGBLOB NULL');

        // VOTES
        Schema::create('votes', function (Blueprint $table) {
            $table->increments('vote_id');
            $table->string('hashed_id', 64)->nullable();
            $table->unsignedInteger('election_id')->nullable();
            $table->unsignedInteger('candidate_id')->nullable();
            $table->string('position', 50)->nullable();
            $table->string('course_or_strand', 50)->nullable();
            $table->string('department', 50)->nullable();
            $table->timestamp('timestamp')->useCurrent();

            $table->unique(['hashed_id', 'election_id', 'position'], 'uq_vote_once');
            $table->foreign('election_id')->references('election_id')->on('elections')->cascadeOnDelete();
            $table->foreign('candidate_id')->references('candidate_id')->on('candidates')->cascadeOnDelete();
        });

    }

    public function down(): void
    {
        Schema::dropIfExists('votes');
        Schema::dropIfExists('candidates');
        Schema::dropIfExists('elections');
        Schema::dropIfExists('user_otps');
        Schema::dropIfExists('users');
        Schema::dropIfExists('faculty');
        Schema::dropIfExists('student');
        Schema::dropIfExists('people');
    }
};
