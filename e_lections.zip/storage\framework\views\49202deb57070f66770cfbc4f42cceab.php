<aside id="sidebar"
    class="w-64 transition-all duration-300 bg-gray-900/90 shadow-2xl p-5
           fixed left-0 top-18 h-[calc(100vh-4rem)] z-30 overflow-y-auto hidden md:block">


    <nav class="space-y-4">
        <?php
            $role = session('role'); // pull role from session
        ?>

        
        <?php if($role === 'Comelec Head'): ?>
            <a href="<?php echo e(route('dashboard')); ?>"
                class="block hover:text-yellow-400 <?php echo e(request()->routeIs('dashboard') ? 'text-yellow-400 font-bold' : 'text-white'); ?>">
                Dashboard
            </a>
            <a href="<?php echo e(route('elections.index')); ?>"
                class="block hover:text-yellow-400 <?php echo e(request()->routeIs('elections.index') ? 'text-yellow-400 font-bold' : 'text-white'); ?>">
                Election Manager </a>
            <a href="<?php echo e(route('candidates')); ?>"
                class="block hover:text-yellow-400 <?php echo e(request()->routeIs('candidates') ? 'text-yellow-400 font-bold' : 'text-white'); ?>">
                Candidates
            </a>
            <a href="<?php echo e(route('results')); ?>"
                class="block hover:text-yellow-400 <?php echo e(request()->routeIs('results', 'view.result') ? 'text-yellow-400 font-bold' : 'text-white'); ?>">
                Results
            </a>
            <a href="<?php echo e(route('logout')); ?>" class="block text-white hover:text-yellow-400">Logout</a>

            
        <?php elseif($role === 'admin'): ?>
            <a href="<?php echo e(route('dashboard')); ?>"
                class="block hover:text-yellow-400 <?php echo e(request()->routeIs('dashboard') ? 'text-yellow-400 font-bold' : 'text-white'); ?>">
                Dashboard
            </a>
            <a href="<?php echo e(route('elections.index')); ?>"
                class="block hover:text-yellow-400 <?php echo e(request()->routeIs('elections.index') ? 'text-yellow-400 font-bold' : 'text-white'); ?>">
                Election Manager </a>
            <a href="<?php echo e(route('candidates')); ?>"
                class="block hover:text-yellow-400 <?php echo e(request()->routeIs('candidates') ? 'text-yellow-400 font-bold' : 'text-white'); ?>">
                Candidates
            </a>
            <a href="<?php echo e(route('results')); ?>"
                class="block hover:text-yellow-400 <?php echo e(request()->routeIs('results', 'view.result') ? 'text-yellow-400 font-bold' : 'text-white'); ?>">
                Results
            </a>
            <a href="<?php echo e(route('logout')); ?>" class="block text-white hover:text-yellow-400">Logout</a>

            
        <?php elseif($role === 'voter'): ?>
            <a href="<?php echo e(route('voting.window')); ?>"
                class="block hover:text-yellow-400 <?php echo e(request()->routeIs('voting.window') ? 'text-yellow-400 font-bold' : 'text-white'); ?>">
                Voting Window
            </a>
            <a href="<?php echo e(route('results')); ?>"
                class="block hover:text-yellow-400 <?php echo e(request()->routeIs('results', 'view.result') ? 'text-yellow-400 font-bold' : 'text-white'); ?>">
                Results
            </a>
            <a href="<?php echo e(route('logout')); ?>" class="block text-white hover:text-yellow-400">Logout</a>
        <?php endif; ?>
    </nav>
</aside>
<?php /**PATH C:\xampp\htdocs\test_app\resources\views\partials\sidebar.blade.php ENDPATH**/ ?>