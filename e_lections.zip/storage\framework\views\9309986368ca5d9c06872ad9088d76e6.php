

<?php $__env->startSection('title', 'Election Manager'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="">
            <h3 class="text-xl font-bold text-yellow-400 mb-4">Election Manager</h3>

            
            <?php if(session('success')): ?>
                <p class="text-green-400 font-semibold mb-4"><?php echo e(session('success')); ?></p>
            <?php endif; ?>

            
            <?php if($errors->any()): ?>
                <div class="text-red-400 mb-4">
                    <ul class="list-disc list-inside">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            
            <form id="create" method="POST" action="<?php echo e(route('schedule.election.store')); ?>" class="section-block mb-6"
                id="create-election-form">
                <?php echo csrf_field(); ?>

                <input type="text" name="title" placeholder="Election Title" required class="input mb-3 w-full">

                <label>Start Time:</label>
                <input type="datetime-local" name="start_time" required class="input mb-3 w-full">

                <label>End Time:</label>
                <input type="datetime-local" name="end_time" required class="input mb-3 w-full">

                <label>Department:</label>
                <?php
                    $userRole = session('role');
                    $isSSOorAdmin = in_array($userRole, ['Student Services Office Head', 'Comelec Head', 'admin']);
                ?>

                <?php if($isSSOorAdmin): ?>
                    <select name="department" required class="input mb-4 w-full">
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dept); ?>"><?php echo e($dept); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                <?php else: ?>
                    <input type="text" name="department" value="<?php echo e($departments->first()); ?>" readonly
                        class="input mb-4 w-full bg-gray-700 text-gray-400">
                <?php endif; ?>

                <label>Available Positions:</label>
                <div class="grid grid-cols-2 gap-2 mb-4">
                    <?php
                        $positionsList = $positionsList ?? [
                            'President',
                            'Vice President - Religious',
                            'Vice President - Social',
                            'Secretary',
                            'Assistant Secretary',
                            'Treasurer',
                            'Assistant Treasurer',
                            'Auditor',
                        ];
                    ?>

                    <?php $__currentLoopData = $positionsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="flex items-center space-x-2">
                            <input type="checkbox" name="positions[]" value="<?php echo e($position); ?>">
                            <span><?php echo e($position); ?></span>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    

                    <div class="col-span-2 mt-3">
                        <label class="block mb-2 font-semibold">Add Custom Positions (comma-separated).
                            New format: <strong>Position - N</strong> (dash indicates max winners). Example:
                            <code>Public Relations Officer - 2, Property Custodian</code>
                        </label>
                        <input type="text" name="custom_positions" id="custom_positions"
                            value="<?php echo e(old('custom_positions')); ?>"
                            placeholder="e.g. Public Relations Officer - 2, Property Custodian"
                            class="input w-full border rounded p-2">
                        <p class="text-sm text-gray-400 mt-1">If you omit <code>- N</code>, it defaults to 1.</p>
                    </div>
                </div>

                <div class="flex justify-center space-x-4">
                    <button type="submit" class="btn btn-save">Create Election</button>
                </div>
            </form>

            
            <h4 class="text-lg font-bold mb-3 text-yellow-300">Existing Elections</h4>

            <?php $__empty_1 = true; $__currentLoopData = $elections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $election): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $now = now();
                    $start = \Carbon\Carbon::parse($election->start_time);
                    $end = \Carbon\Carbon::parse($election->end_time);
                    $status = $now->lt($start) ? 'upcoming' : ($now->between($start, $end) ? 'ongoing' : 'ended');

                    // ensure positions variable for edit forms
                    $positions = is_array($election->positions)
                        ? $election->positions
                        : (is_string($election->positions)
                            ? json_decode($election->positions, true) ?? []
                            : []);
                ?>

                <?php if($status === 'ended'): ?>
                    <?php continue; ?>
                <?php endif; ?>

                <div id="elect" class= "mb-8 border border-gray-700 rounded-lg p-4"
                    style="background-color: rgba(255, 255, 255, 0.1); border: 1px solid rgba(255, 255, 255, 0.2); border-radius: 0.75rem; padding: 1rem; margin-bottom: 1.5rem; box-shadow: 0 4px 20px rgba(0,0,0,0.3);"
                    data-department="<?php echo e($election->department); ?>" data-election-id="<?php echo e($election->election_id); ?>">
                    <div class="flex justify-between items-center">
                        <div>
                            <p class="font-bold text-white text-lg"><?php echo e($election->title); ?></p>
                            <p class="text-gray-400 text-sm">
                                <?php echo e(ucfirst($election->department)); ?> —
                                <?php echo e($start->format('M d, Y h:i A')); ?> to <?php echo e($end->format('M d, Y h:i A')); ?>

                            </p>
                            <p class="text-sm mt-1">
                                Status:
                                <span
                                    class="<?php echo e($status === 'upcoming' ? 'text-blue-400' : ($status === 'ongoing' ? 'text-green-400' : 'text-red-400')); ?> font-semibold">
                                    <?php echo e(ucfirst($status)); ?>

                                </span>
                            </p>
                        </div>

                        <div class="flex space-x-2 ">
                            <?php
                                $canEdit = $isSSOorAdmin || $departments->contains($election->department);
                            ?>

                            <?php if($status === 'upcoming' && $canEdit): ?>
                                <button onclick="openModal('<?php echo e($election->election_id); ?>')" type="button"
                                    class="btn btn-warning toggle-edit" data-election="<?php echo e($election->election_id); ?>">
                                    Edit
                                </button>
                                <form action="<?php echo e(route('elections.destroy', $election->election_id)); ?>" method="POST"
                                    onsubmit="return confirm('Are you sure you want to delete this election?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="button"
                                        onclick="openDeleteModal('<?php echo e(route('elections.destroy', $election->election_id)); ?>')"
                                        class="btn btn-danger">
                                        Delete
                                    </button>

                                </form>
                            <?php else: ?>
                                <span class="text-gray-500 italic">Editing disabled</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <hr class="my-3 border-gray-700">

                    <p class="text-yellow-300 font-semibold">Positions (max winners shown if set):</p>
                    <ul class="list-disc list-inside text-gray-300 mb-3">
                        <?php
                            $maxWinners = is_array($election->max_winners)
                                ? $election->max_winners
                                : (is_string($election->max_winners)
                                    ? json_decode($election->max_winners, true) ?? []
                                    : []);
                        ?>
                        <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($pos); ?> <?php if(isset($maxWinners[$pos])): ?>
                                    — max: <?php echo e($maxWinners[$pos]); ?>

                                <?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                    <p class="text-yellow-300 font-semibold">Candidates:</p>
                    <ul class="list-none text-gray-300 space-y-3">
                        <?php $__empty_2 = true; $__currentLoopData = $election->candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                            <li class="flex flex-col bg-gray-800 p-2 rounded-lg">
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center space-x-3">
                                        <?php if($candidate->photo): ?>
                                            <img src="data:image/jpeg;base64,<?php echo e(base64_encode($candidate->photo)); ?>"
                                                alt="Candidate Photo"
                                                class="w-12 h-12 rounded-full object-cover border border-yellow-400">
                                        <?php else: ?>
                                            <div
                                                class="w-12 h-12 rounded-full bg-gray-600 flex items-center justify-center text-sm text-gray-300">
                                                No Photo
                                            </div>
                                        <?php endif; ?>

                                        <div>
                                            <p class="font-semibold"><?php echo e($candidate->name); ?></p>
                                            <p class="text-sm text-gray-400"><?php echo e($candidate->position); ?> —
                                                <?php echo e($candidate->partylist); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                            <li class="text-gray-400 italic">No candidates yet.</li>
                        <?php endif; ?>
                    </ul>

                    <!-- Modal -->
                    
                    <div id="editModal-<?php echo e($election->election_id); ?>"
                        class="hidden absolute inset-0 z-50 bg-black/60 backdrop-blur-sm pt-12 pl-72">
                        <!-- Modal Box -->
                        <div style="height: 600px; width: 900px;"
                            class="relative overflow-y-auto bg-gray-800 rounded-lg shadow-lg p-6">

                            <!-- Close Button -->
                            <button onclick="closeModal('<?php echo e($election->election_id); ?>')"
                                class="absolute top-3 right-3 text-gray-300 hover:text-white text-2xl">&times;</button>

                            <h2 class="text-xl font-bold mb-4">Edit Election</h2>

                            
                            <form method="post" action="<?php echo e(route('elections.update', $election->election_id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <label class="block mb-1 font-semibold">Election Title:</label>
                                <input type="text" name="title" value="<?php echo e($election->title); ?>"
                                    class="input mb-3 w-full">

                                <label class="block mb-1 font-semibold">Start Time:</label>
                                <input type="datetime-local" name="start_time"
                                    value="<?php echo e(\Carbon\Carbon::parse($election->start_time)->format('Y-m-d\TH:i')); ?>"
                                    class="input mb-3 w-full">

                                <label class="block mb-1 font-semibold">End Time:</label>
                                <input type="datetime-local" name="end_time"
                                    value="<?php echo e(\Carbon\Carbon::parse($election->end_time)->format('Y-m-d\TH:i')); ?>"
                                    class="input mb-3 w-full">

                                <label class="block mb-1 font-semibold">Department:</label>
                                <?php if($isSSOorAdmin): ?>
                                    <select name="department" class="input mb-3 w-full">
                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($dept); ?>"
                                                <?php echo e($election->department == $dept ? 'selected' : ''); ?>>
                                                <?php echo e($dept); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                <?php else: ?>
                                    <input type="text" name="department" value="<?php echo e($election->department); ?>" readonly
                                        class="input mb-3 w-full bg-gray-700 text-gray-400">
                                <?php endif; ?>

                                <?php
                                    $existingPositions = is_array($positions)
                                        ? $positions
                                        : (is_string($positions)
                                            ? json_decode($positions, true) ?? []
                                            : []);
                                    $otherPositions = array_values(array_diff($existingPositions, $positionsList));
                                    $otherPositionsString = implode(', ', $otherPositions);
                                    $maxWinners = is_array($election->max_winners)
                                        ? $election->max_winners
                                        : (is_string($election->max_winners)
                                            ? json_decode($election->max_winners, true) ?? []
                                            : []);
                                    foreach ($existingPositions as $pos) {
                                        if (!isset($maxWinners[$pos])) {
                                            $maxWinners[$pos] = 1;
                                        }
                                    }
                                ?>

                                <label class="block mb-2 font-semibold">Available Positions:</label>
                                <div class="grid grid-cols-2 gap-2 mb-4">
                                    <?php $__currentLoopData = $positionsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="flex items-center space-x-2">
                                            <input type="checkbox" name="positions[]" value="<?php echo e($position); ?>"
                                                <?php echo e(in_array($position, $existingPositions) ? 'checked' : ''); ?>>
                                            <span><?php echo e($position); ?></span>
                                        </label>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <div class="col-span-2 mt-3">
                                        <label class="block mb-2 font-semibold">Add Custom Positions
                                            (comma-separated):</label>
                                        <input type="text" name="custom_positions"
                                            placeholder="e.g. Public Relations Officer - 2, Property Custodian"
                                            class="input w-full border rounded p-2"
                                            value="<?php echo e(old('custom_positions', $otherPositionsString)); ?>">
                                        <p class="text-sm text-gray-400 mt-1">(Currently:
                                            <?php echo e($otherPositionsString ?: 'None'); ?>)</p>
                                    </div>

                                    <div class="col-span-2 mt-3">
                                        <label class="block mb-2 font-semibold">Set Maximum Winners per Position:</label>
                                        <div class="grid grid-cols-2 gap-2">
                                            <?php $__currentLoopData = $existingPositions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="flex items-center space-x-2">
                                                    <label class="w-2/3"><?php echo e($position); ?></label>
                                                    <input type="number" name="max_winners[<?php echo e($position); ?>]"
                                                        min="1"
                                                        value="<?php echo e(old('max_winners.' . $position, $maxWinners[$position])); ?>"
                                                        class="input w-1/3">
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <p class="text-sm text-gray-400 mt-1">(Defaults to 1 if left blank.)</p>
                                    </div>
                                </div>

                                <div class="flex justify-center space-x-3 mt-6">
                                    <button type="submit" class="btn btn-save">Save Changes</button>
                                    <button type="button" class="btn btn-warning"
                                        onclick="closeModal('<?php echo e($election->election_id); ?>')">Cancel</button>
                                </div>
                            </form>

                            
                            <h4 class="text-yellow-300 font-semibold mt-6">Candidates</h4>
                            <ul class="list-none text-gray-300 space-y-3">
                                <?php $__empty_2 = true; $__currentLoopData = $election->candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                    <li class="flex flex-col bg-gray-800 p-2 rounded-lg">
                                        <div class="flex flex-col bg-gray-800 p-2 rounded-lg">
                                            <div class="flex items-center justify-between">
                                                <div class="flex items-center space-x-3">
                                                    <?php if($candidate->photo): ?>
                                                        <img src="data:image/jpeg;base64,<?php echo e(base64_encode($candidate->photo)); ?>"
                                                            alt="Candidate Photo"
                                                            class="w-12 h-12 rounded-full object-cover border border-yellow-400">
                                                    <?php else: ?>
                                                        <div
                                                            class="w-12 h-12 rounded-full bg-gray-600 flex items-center justify-center text-sm text-gray-300">
                                                            No Photo
                                                        </div>
                                                    <?php endif; ?>
                                                    <div class="flex flex-col">
                                                        <p class="font-semibold text-gray-200"><?php echo e($candidate->name); ?></p>
                                                        <p class="text-sm text-gray-400"><?php echo e($candidate->position); ?> —
                                                            <?php echo e($candidate->partylist); ?></p>
                                                    </div>
                                                </div>

                                                <div class="flex space-x-2">
                                                    <button type="button"
                                                        class="btn btn-warning btn-sm toggle-candidate-edit"
                                                        data-id="<?php echo e($candidate->candidate_id); ?>">
                                                        Edit
                                                    </button>
                                                    <form
                                                        action="<?php echo e(route('candidates.remove', $candidate->candidate_id)); ?>"
                                                        method="POST"
                                                        onsubmit="return confirm('Remove this candidate?')">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="button"
                                                            onclick="openDeleteModal('<?php echo e(route('candidates.remove', $candidate->candidate_id)); ?>')"
                                                            class="btn btn-danger btn-sm">
                                                            Remove
                                                        </button>
                                                    </form>
                                                </div>
                                            </div>

                                            
                                            <form action="<?php echo e(route('candidates.update', $candidate->candidate_id)); ?>"
                                                method="POST" enctype="multipart/form-data"
                                                id="candidate-edit-form-<?php echo e($candidate->candidate_id); ?>"
                                                class="hidden mt-3 border-t border-gray-700 pt-3">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>

                                                <!-- Candidate Search -->
                                                <!-- Candidate Name (Read-only) -->
                                                <label class="block mb-2 font-semibold">Candidate Name:</label>
                                                <input type="text" name="candidate_name"
                                                    value="<?php echo e($candidate->name); ?>"
                                                    class="input mb-2 w-full bg-gray-700 text-gray-300 cursor-not-allowed"
                                                    readonly>

                                                <!-- Hidden ID if needed -->
                                                <input type="hidden" name="id_number"
                                                    value="<?php echo e($candidate->id_number); ?>">
                                                <!-- Partylist -->
                                                <input type="text" name="partylist" placeholder="Partylist"
                                                    class="input mb-2 w-full" value="<?php echo e($candidate->partylist); ?>">

                                                <!-- Position -->
                                                <label class="block mb-2">Select Position:</label>
                                                <select name="position" required class="input mb-4 w-full">
                                                    <?php $__currentLoopData = $existingPositions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($pos); ?>"
                                                            <?php echo e($pos == $candidate->position ? 'selected' : ''); ?>>
                                                            <?php echo e($pos); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                                <!-- Photo Upload -->
                                                <div class="flex flex-col items-center mb-6">
                                                    <label class="block mb-2">Photo:</label>
                                                    <label for="candidate-photo-<?php echo e($candidate->candidate_id); ?>"
                                                        class="cursor-pointer w-32 h-32 rounded-md bg-yellow-500 flex items-center justify-center text-black font-semibold text-center hover:bg-yellow-400 transition overflow-hidden relative">
                                                        <span id="photo-text-<?php echo e($candidate->candidate_id); ?>"
                                                            class="px-2 text-sm">Upload Candidate Photo</span>
                                                        <?php if($candidate->photo): ?>
                                                            <img id="photo-preview-<?php echo e($candidate->candidate_id); ?>"
                                                                src="data:image/jpeg;base64,<?php echo e(base64_encode($candidate->photo)); ?>"
                                                                class="absolute inset-0 w-full h-full object-cover" />
                                                        <?php else: ?>
                                                            <img id="photo-preview-<?php echo e($candidate->candidate_id); ?>"
                                                                class="absolute inset-0 w-full h-full object-cover hidden" />
                                                        <?php endif; ?>
                                                    </label>
                                                    <input type="file" name="photo"
                                                        id="candidate-photo-<?php echo e($candidate->candidate_id); ?>"
                                                        accept="image/*" class="hidden"
                                                        onchange="previewImage(event, <?php echo e($candidate->candidate_id); ?>)" />
                                                </div>

                                                <div class="flex justify-center space-x-2">
                                                    <button type="submit" class="btn btn-save btn-sm">Save</button>
                                                    <button type="button"
                                                        class="btn btn-warning btn-sm toggle-candidate-edit"
                                                        data-id="<?php echo e($candidate->candidate_id); ?>">Cancel</button>
                                                </div>
                                            </form>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                    <li class="text-gray-400 italic">No candidates yet.</li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>



                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-gray-400 italic">No elections scheduled yet.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="confirmModal" class="fixed inset-0 bg-black/30 backdrop-blur-sm hidden items-center justify-center z-50">
        <div class="bg-gray-800/80 p-6 rounded-xl shadow-xl w-96">
            <h2 class="text-xl font-bold mb-4 text-white">Are you sure?</h2>
            <p class="text-gray-300 mb-6">This action cannot be undone.</p>

            <div class="flex justify-end space-x-3">
                <button id="cancelBtn" class="px-4 py-2 bg-gray-600/80 hover:bg-gray-700/80 text-white rounded-lg">
                    Cancel
                </button>

                <form id="confirmForm" method="POST" action="">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_method" value="DELETE">
                    <button type="submit" class="px-4 py-2 bg-red-600/80 hover:bg-red-700/80 text-white rounded-lg">
                        Confirm
                    </button>
                </form>
            </div>
        </div>
    </div>



    
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Toggle edit forms & candidate action visibility
            document.querySelectorAll('.toggle-edit').forEach(button => {
                button.addEventListener('click', () => {
                    const id = button.dataset.election;
                    const modal = document.getElementById(`editModal-${id}`);
                    if (modal) modal.classList.remove('hidden');
                });
            });

            // Candidate edit toggle
            document.querySelectorAll('.toggle-candidate-edit').forEach(btn => {
                btn.addEventListener('click', () => {
                    const id = btn.dataset.id;
                    const form = document.getElementById(`candidate-edit-form-${id}`);
                    if (form) form.classList.toggle('hidden');
                });
            });

            // Student autocomplete inputs
            document.querySelectorAll('.student-search').forEach(input => {
                // create wrapper & result list
                const wrapper = document.createElement('div');
                wrapper.style.position = 'relative';
                input.parentNode.insertBefore(wrapper, input);
                wrapper.appendChild(input);

                const resultList = document.createElement('ul');
                resultList.classList.add('absolute', 'bg-gray-800', 'text-gray-200', 'border',
                    'border-gray-600', 'rounded', 'w-full', 'max-h-40', 'overflow-y-auto', 'hidden',
                    'z-20');
                resultList.style.listStyle = 'none';
                resultList.style.margin = '0';
                resultList.style.padding = '0';
                wrapper.appendChild(resultList);

                // department comes from data attribute placed on the input
                const departmentFromInput = input.dataset.department || input.closest('.section-block')
                    ?.dataset.department || 'General';

                let debounce = null;
                input.addEventListener('input', () => {
                    clearTimeout(debounce);
                    const q = input.value.trim();
                    if (q.length < 2) {
                        resultList.classList.add('hidden');
                        return;
                    }

                    debounce = setTimeout(() => {
                        const department = input.dataset.department ||
                            departmentFromInput || 'General';
                        const url =
                            `<?php echo e(route('students.search')); ?>?query=${encodeURIComponent(q)}&department=${encodeURIComponent(department)}`;

                        fetch(url)
                            .then(res => res.json())
                            .then(data => {
                                resultList.innerHTML = '';
                                if (!Array.isArray(data) || data.length === 0) {
                                    resultList.classList.add('hidden');
                                    return;
                                }

                                data.forEach(student => {
                                    const li = document.createElement('li');
                                    li.textContent =
                                        `${student.full_name} (${student.id_number})`;
                                    li.classList.add('px-3', 'py-2',
                                        'hover:bg-gray-700',
                                        'cursor-pointer');
                                    li.style.borderBottom =
                                        '1px solid rgba(255,255,255,0.03)';
                                    li.addEventListener('click', () => {
                                        // Put the selected value into the input (for display). If your form needs hidden id, add that handling.
                                        input.value =
                                            `${student.full_name} (${student.id_number})`;
                                        // if there's a hidden input for id, fill it (common pattern: name="student_id")
                                        const hidden = input.closest(
                                            'form')?.querySelector(
                                            'input[type="hidden"][name="student_id"]'
                                        );
                                        if (hidden) hidden.value =
                                            student.id_number || '';
                                        resultList.classList.add(
                                            'hidden');
                                    });
                                    resultList.appendChild(li);
                                });

                                resultList.classList.remove('hidden');
                            }).catch(err => {
                                console.error('Student search error', err);
                                resultList.classList.add('hidden');
                            });
                    }, 250);
                });

                // click outside to hide results
                document.addEventListener('click', (evt) => {
                    if (!wrapper.contains(evt.target)) resultList.classList.add('hidden');

                });
            });

            // Photo preview
            window.previewImage = function(event) {
                const input = event.target;
                const idSuffix = input.id.replace('candidate-photo-', '');
                const preview = document.getElementById(`photo-preview-${idSuffix}`);
                const labelText = document.getElementById(`photo-text-${idSuffix}`);

                if (input.files && input.files[0]) {
                    const reader = new FileReader();
                    reader.onload = e => {
                        preview.src = e.target.result;
                        preview.classList.remove('hidden');
                        if (labelText) labelText.classList.add('hidden');
                    };
                    reader.readAsDataURL(input.files[0]);
                }
            };
        });

        function openModal(id) {
            document.getElementById('create').classList.add('hidden');
            document.getElementById(`editModal-${id}`).classList.remove('hidden');
            document.body.classList.add("overflow-y-auto");
        }

        function closeModal(id) {
            document.getElementById(`editModal-${id}`).classList.add('hidden');
            document.getElementById('create').classList.remove('hidden');
            document.body.classList.remove("overflow-hidden");
        }

        document.addEventListener('click', function(e) {
            document.querySelectorAll('[id^="editModal-"]').forEach(modal => {
                if (!modal.classList.contains('hidden') && e.target === modal) {
                    modal.classList.add('hidden');
                    document.getElementById('create').classList.remove('hidden')
                    document.body.classList.remove("overflow-hidden");
                }
            });
        });
    </script>
    <script>
        const modal = document.getElementById('confirmModal');
        const confirmForm = document.getElementById('confirmForm');
        const cancelBtn = document.getElementById('cancelBtn');

        function openDeleteModal(url) {
            confirmForm.action = url;
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }

        cancelBtn.addEventListener('click', () => {
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        });

        modal.addEventListener('click', e => {
            if (e.target === modal) {
                modal.classList.add('hidden');
                modal.classList.remove('flex');
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\test_app\resources\views/schedule_election.blade.php ENDPATH**/ ?>