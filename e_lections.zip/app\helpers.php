<?php

use Illuminate\Support\Facades\DB;

if (!function_exists('hashVoter')) {
    function hashVoter($id)
    {
        // keep the same logic for consistency
        return hash('sha256', $id . config('app.key'));
    }
}

if (!function_exists('hasVoted')) {
    function hasVoted($conn, $hashed_id, $election_id)
    {
        return DB::table('votes')
            ->where('election_id', $election_id)
            ->where('hashed_id', $hashed_id)
            ->exists();
    }
}

if (!function_exists('recordVote')) {
    function recordVote($conn, $hashed_id, $election_id, $candidate_id, $position, $course_or_strand, $department)
    {
        DB::table('votes')->insert([
            'hashed_id' => $hashed_id,
            'election_id' => $election_id,
            'candidate_id' => $candidate_id,
            'position' => $position,
            'course_or_strand' => $course_or_strand,
            'department' => $department,
            'timestamp' => now(),
        ]);
    }
}
