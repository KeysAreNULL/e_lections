


<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container flex justify-center items-center min-h-[70vh]">
        <div class="section-block max-w-md w-full p-8">

            <h2 class="text-2xl font-bold text-yellow-400 text-center mb-6">Login to E-lections</h2>

            
            <form method="POST" action="<?php echo e(route('send.otp')); ?>" class="mb-8">
                <?php echo csrf_field(); ?>
                <input type="text" name="id_number" placeholder="ID Number" class="input w-full mb-4" required>
                <button type="submit" class="btn btn-save w-full">
                    Send OTP
                </button>
            </form>

            
            <form method="POST" action="<?php echo e(route('verify.otp')); ?>">
                <?php echo csrf_field(); ?>
                <input type="text" name="otp_code" placeholder="6-digit OTP" maxlength="6" class="input w-full mb-4"
                    required>
                <button type="submit" class="w-full py-3 bg-green-600 hover:bg-green-700 rounded font-semibold transition">
                    Login
                </button>
            </form>

            
            <?php if(session('error')): ?>
                <p class="text-red-400 mt-4 text-center font-semibold"><?php echo e(session('error')); ?></p>
            <?php endif; ?>

            <?php if(session('success')): ?>
                <p class="text-green-400 mt-4 text-center font-semibold"><?php echo e(session('success')); ?></p>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\test_app\resources\views\auth\login.blade.php ENDPATH**/ ?>