<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Election;
use App\Models\Candidate;
use Carbon\Carbon;

class VotingController extends Controller
{
    /**
     * Show voting window.
     *
     * Loads currently active elections filtered by department.
     * Preserves position order and provides max_winners per position to the view.
     */
    public function show(Request $request)
    {
        $id = session('id_number');
        if (!$id) {
            return redirect()->route('login')->with('error', 'Please log in first.');
        }

        // hashed voter id for your vote-record helpers
        $hashed = hashVoter($id);

        // get user data (student or faculty) to filter department
        $userData = DB::table('student')->where('id_number', $id)->first()
            ?? DB::table('faculty')->where('id_number', $id)->first();

        $now = Carbon::now(config('app.timezone'));

        // Only get currently valid elections by time and department
        $elections = Election::where(function ($query) use ($now) {
            $query->where('start_time', '<=', $now)
                ->where('end_time', '>', $now);
        })
            ->where(function ($query) use ($userData) {
                $query->whereNull('department')
                    ->orWhere('department', 'General');

                if (!empty($userData->department)) {
                    $query->orWhere('department', $userData->department);
                }
            })
            ->orderBy('start_time', 'desc')
            ->get();

        $selectedElectionId = $request->old('select_election') ?? $request->input('select_election');

        $positions = [];
        $maxWinners = []; // associative array: position => max
        $hasVoted = false;
        $isValid = false;

        if ($selectedElectionId) {
            $election = Election::with('candidates')->find($selectedElectionId);

            if ($election) {
                // validate election by time
                $start = $election->start_time ? Carbon::parse($election->start_time) : null;
                $end = $election->end_time ? Carbon::parse($election->end_time) : null;

                $isActiveNow = $start && $end ? ($now->gte($start) && $now->lt($end)) : false;
                $isValid = $isActiveNow;

                if ($isValid) {
                    $hasVoted = hasVoted(DB::connection(), $hashed, $selectedElectionId);

                    if (!$hasVoted) {
                        // Preserve position order from DB
                        $posList = $election->positions ?? [];
                        if (!is_array($posList)) {
                            $posList = json_decode($election->positions, true) ?: [];
                        }

                        // decode max_winners from election
                        $mw = $election->max_winners ?? [];
                        if (!is_array($mw)) {
                            $mw = json_decode($election->max_winners, true) ?: [];
                        }

                        // Build positions in DB order
                        foreach ($posList as $pos) {
                            $cands = $election->candidates
                                ->where('position', $pos)
                                ->values();
                            $positions[$pos] = $cands;
                            $maxWinners[$pos] = isset($mw[$pos]) ? intval($mw[$pos]) : 1;
                        }

                        // Include candidates whose position isn’t listed in the positions column (append)
                        $known = $posList;
                        $extra = $election->candidates->filter(function ($c) use ($known) {
                            return !in_array($c->position, $known);
                        });

                        if ($extra->isNotEmpty()) {
                            $extraGrouped = $extra->groupBy('position');
                            foreach ($extraGrouped as $pos => $group) {
                                $positions[$pos] = $group->values();
                                $maxWinners[$pos] = isset($mw[$pos]) ? intval($mw[$pos]) : 1;
                            }
                        }
                    }
                }
            }
        }

        return view('voting_window', [
            'elections' => $elections,
            'selectedElection' => $selectedElectionId,
            'positions' => $positions,
            'hasVoted' => $hasVoted,
            'isValid' => $isValid,
            'maxWinners' => $maxWinners,
        ]);
    }

    /**
     * Preserve election selection on change.
     */
    public function select(Request $request)
    {
        return redirect()->back()->withInput();
    }

    /**
     * Submit votes.
     *
     * Handles both single- and multi-winner positions.
     * Performs server-side enforcement of max_winners and calls recordVote for each candidate chosen.
     */
    public function submit(Request $request)
    {
        $id = session('id_number');
        if (!$id) {
            return redirect()->route('login')->with('error', 'Please log in first.');
        }

        $hashed = hashVoter($id);
        $userData = DB::table('student')->where('id_number', $id)->first()
            ?? DB::table('faculty')->where('id_number', $id)->first();

        $selectedElection = $request->input('select_election');
        if (!$selectedElection) {
            return redirect()->back()->with('error', 'No election selected.');
        }

        $election = Election::find($selectedElection);
        if (!$election) {
            return redirect()->back()->with('error', 'Election not found.');
        }

        $now = Carbon::now(config('app.timezone'));
        $start = $election->start_time ? Carbon::parse($election->start_time) : null;
        $end = $election->end_time ? Carbon::parse($election->end_time) : null;
        $isActiveNow = $start && $end ? ($now->gte($start) && $now->lt($end)) : false;

        if (!$isActiveNow) {
            return redirect()->back()->with('error', 'Election is not active.');
        }

        if (hasVoted(DB::connection(), $hashed, $selectedElection)) {
            return redirect()->back()->with('error', 'You have already voted in this election.');
        }

        // decode max_winners for server-side enforcement
        $mw = $election->max_winners ?? [];
        if (!is_array($mw)) {
            $mw = json_decode($election->max_winners, true) ?: [];
        }

        // iterate request inputs and process fields that follow the election__position pattern
        $inputs = $request->all();

        // We'll validate counts first (collect violations)
        $violations = [];

        foreach ($inputs as $field => $value) {
            if (!is_string($field) || !str_contains($field, '__')) {
                continue;
            }

            // normalize position key: strip trailing [] if present (when checkboxes)
            $isArrayField = false;
            if (str_ends_with($field, '[]')) {
                $isArrayField = true;
                $normField = substr($field, 0, -2);
            } else {
                $normField = $field;
            }

            // split election_id and position (position may contain spaces)
            [$election_id_str, $position] = explode('__', $normField, 2);
            $election_id = intval($election_id_str);

            // skip inputs not for the selected election
            if ($election_id !== intval($selectedElection)) {
                continue;
            }

            $chosen = $value;
            if ($isArrayField && is_array($chosen)) {
                $count = count($chosen);
            } elseif (is_array($chosen)) {
                // rare: PHP may decode multiple same-named non-[] fields as array; handle conservatively
                $count = count($chosen);
            } else {
                $count = ($chosen === null || $chosen === '') ? 0 : 1;
            }

            $allowed = isset($mw[$position]) ? max(1, intval($mw[$position])) : 1;
            if ($count > $allowed) {
                $violations[] = "You selected {$count} for {$position} but only {$allowed} allowed.";
            }
        }

        if (!empty($violations)) {
            return redirect()->back()->withErrors($violations)->withInput();
        }

        // No violations — record votes
        foreach ($inputs as $field => $value) {
            if (!is_string($field) || !str_contains($field, '__')) {
                continue;
            }

            // normalize field name and election/position
            $isArrayField = false;
            if (str_ends_with($field, '[]')) {
                $isArrayField = true;
                $normField = substr($field, 0, -2);
            } else {
                $normField = $field;
            }

            [$election_id_str, $position] = explode('__', $normField, 2);
            $election_id = intval($election_id_str);
            if ($election_id !== intval($selectedElection)) {
                continue;
            }

            if ($isArrayField && is_array($value)) {
                foreach ($value as $candidateId) {
                    $candidateId = intval($candidateId);
                    if ($candidateId <= 0)
                        continue;
                    recordVote(
                        DB::connection(),
                        $hashed,
                        $election_id,
                        $candidateId,
                        $position,
                        $userData->course_or_strand ?? '',
                        $userData->department ?? ''
                    );
                }
            } elseif (is_array($value)) {
                // defensive: array without [] (take each)
                foreach ($value as $candidateId) {
                    $candidateId = intval($candidateId);
                    if ($candidateId <= 0)
                        continue;
                    recordVote(
                        DB::connection(),
                        $hashed,
                        $election_id,
                        $candidateId,
                        $position,
                        $userData->course_or_strand ?? '',
                        $userData->department ?? ''
                    );
                }
            } else {
                $candidateId = intval($value);
                if ($candidateId <= 0)
                    continue;
                recordVote(
                    DB::connection(),
                    $hashed,
                    $election_id,
                    $candidateId,
                    $position,
                    $userData->course_or_strand ?? '',
                    $userData->department ?? ''
                );
            }
        }

        return redirect()->route('voting.window')->with('success', 'Votes submitted successfully!');
    }
}
