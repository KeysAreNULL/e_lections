
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title', 'CPAC E-lections'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="font-sans bg-black text-white min-h-screen relative">

    <!-- Background Video & Overlay -->
     <div class="background-overlay"></div>
    <div class="background-wrapper absolute inset-0 z-0">
        <img src="<?php echo e(asset('videos/background.jpg')); ?>" alt="Background" class="w-full h-full object-cover">
    </div>

    <!-- Content Wrapper -->
    <div class="relative z-20 flex flex-col min-h-screen">
        <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <main class="flex-1 flex items-center justify-center p-6">
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\test_app\resources\views\layouts\guest.blade.php ENDPATH**/ ?>