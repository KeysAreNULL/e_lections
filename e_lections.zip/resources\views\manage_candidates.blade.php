@extends('layouts.app')

@section('title', 'Manage Candidates')

@section('content')
    <div class="container">
        <div class="section-block">
            <h3 class="text-xl font-bold text-yellow-400 mb-4">Manage Candidates</h3>

            @if (session('success'))
                <p class="text-green-400 font-semibold mb-4">{{ session('success') }}</p>
            @endif
            @if ($errors->any())
                <div class="text-red-400 mb-4">
                    <ul class="list-disc list-inside">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form method="POST" action="{{ route('candidates.store') }}" enctype="multipart/form-data"
                class="section-block mb-6">
                @csrf

                <!-- Election Select -->
                <label class="block mb-2">Select Election:</label>
                <select name="election_id" id="election-select" required class="input mb-4 w-full">
                    <option value="" disabled selected>-- Choose Election --</option>
                    @foreach ($elections as $election)
                        @php
                            $now = now();
                            $start = \Carbon\Carbon::parse($election->start_time);
                            $end = \Carbon\Carbon::parse($election->end_time);
                            $status = $now->lt($start)
                                ? 'upcoming'
                                : ($now->between($start, $end)
                                    ? 'ongoing'
                                    : 'ended');
                        @endphp
                        @if ($status === 'upcoming')
                            <option value="{{ $election->election_id }}">
                                {{ $election->title }} ({{ $election->department }})
                            </option>
                        @endif
                    @endforeach
                </select>

                <!-- Candidate Search -->
                <label class="block mb-2">Search Student:</label>
                <input type="text" id="student-search" placeholder="Type student name..." class="input mb-2 w-full"
                    autocomplete="off">
                <ul id="search-results"
                    class="bg-gray-800 text-gray-200 border border-gray-600 rounded w-full max-h-40 overflow-y-auto hidden">
                </ul>
                <input type="hidden" name="id_number" id="id-number">

                <!-- Photo Upload -->
                <div class="flex flex-col items-center mb-6">
                    <label class="block mb-2">Photo:</label>
                    <label for="candidate-photo"
                        class="cursor-pointer w-32 h-32 rounded-md bg-yellow-500 flex items-center justify-center text-black font-semibold text-center hover:bg-yellow-400 transition overflow-hidden relative">
                        <span id="photo-text" class="px-2 text-sm">Upload Candidate Photo</span>
                        <img id="photo-preview" class="absolute inset-0 w-full h-full object-cover hidden" />
                    </label>
                    <input type="file" name="photo" id="candidate-photo" accept="image/*" class="hidden"
                        onchange="previewImage(event)" />
                </div>

                <!-- Position -->
                <label class="block mb-2">Select Position:</label>
                <select name="position" required class="input mb-2 w-full" id="position-dropdown">
                    <option value="" disabled selected>-- Choose Position --</option>
                </select>

                <!-- Partylist -->
                <input type="text" name="partylist" placeholder="Partylist" required class="input mb-4 w-full">

                <div class="flex justify-center space-x-4">
                    <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md">
                        Save Candidate
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        document.getElementById('student-search').addEventListener('input', function() {
            const query = this.value;
            const electionSelect = document.getElementById('election-select');
            const selectedOption = electionSelect.options[electionSelect.selectedIndex];
            const selectedElectionText = selectedOption ? selectedOption.text : '';
            const departmentMatch = selectedElectionText.match(/\((.*?)\)/);
            const department = departmentMatch ? departmentMatch[1] : null;

            if (query.length < 2) {
                document.getElementById('search-results').classList.add('hidden');
                return;
            }

            fetch(`{{ route('students.search') }}?query=${query}&department=${encodeURIComponent(department)}`)
                .then(res => res.json())
                .then(data => {
                    let results = '';
                    data.forEach(student => {
                        results +=
                            `<li class="px-3 py-2 hover:bg-gray-700 cursor-pointer" onclick="selectStudent('${student.id_number}', '${student.full_name}')">${student.full_name} (${student.id_number})</li>`;
                    });
                    const resultsList = document.getElementById('search-results');
                    resultsList.innerHTML = results;
                    resultsList.classList.remove('hidden');
                });
        });

        function selectStudent(idNumber, fullName) {
            document.getElementById('id-number').value = idNumber;
            document.getElementById('student-search').value = `${fullName} (${idNumber})`;
            document.getElementById('search-results').classList.add('hidden');
        }

        function previewImage(event) {
            const input = event.target;
            const preview = document.getElementById('photo-preview');
            const labelText = document.getElementById('photo-text');

            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = e => {
                    preview.src = e.target.result;
                    preview.classList.remove('hidden');
                    labelText.classList.add('hidden');
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

        // Hide search results when clicking outside
        document.addEventListener('click', function(event) {
            const searchInput = document.getElementById('student-search');
            const searchResults = document.getElementById('search-results');

            if (!searchInput.contains(event.target) && !searchResults.contains(event.target)) {
                searchResults.classList.add('hidden');
            }
        });
    </script>
    <script>
        const elections = @json($electionsForJs);
        const electionSelect = document.getElementById('election-select');
        const positionDropdown = document.getElementById('position-dropdown');

        electionSelect.addEventListener('change', function() {
            const selectedId = parseInt(this.value);
            const election = elections.find(e => e.election_id === selectedId);

            // clear old options
            positionDropdown.innerHTML = '<option value="" disabled selected>-- Choose Position --</option>';

            if (election && Array.isArray(election.positions)) {
                election.positions.forEach(pos => {
                    if (pos) {
                        const opt = document.createElement('option');
                        opt.value = pos;
                        opt.textContent = pos; // correct text rendering
                        positionDropdown.appendChild(opt);
                    }
                });
            }
        });
    </script>

@endsection
