<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        $emails = [
            'keitharnelariston@gmail.com',
            'ynelariston@gmail.com',
            'mcchibi123@gmail.com',
            'richlylowell@gmail.com',
            'gcmeteoro@gmail.com',
        ];

        $departments = [
            'Engineering and Technology' => [
                'BS Information Systems',
                'BS Civil Engineering',
                'BS Agriculture',
                'BS Electronics Engineering',
            ],
            'Business and Accountancy' => [
                'BS Financial Management',
                'BS Office Administration',
            ],
            'Sciences, Arts and Education' => [
                'BS Education - Math',
                'BS Education - English',
                'BS Education - PEHM',
                'BS Secondary Education - Science',
                'BS Secondary Education - English',
                'BS Music Education',
                'BS Psychology',
                'BS Biology',
            ],
            'Nursing' => [
                'BS Nursing',
            ],
            'Theology' => [
                'AB Theology',
            ],
            'Student Services Office' => [
                'N/A',
            ],
        ];

        $personId = 1;
        $emailIndex = 0;
        $studentsByDeptCourse = [];

        // -------------------------------
        // STUDENTS
        // -------------------------------
        foreach ($departments as $department => $courses) {
            foreach ($courses as $course) {
                if ($course !== 'N/A') {
                    for ($i = 1; $i <= 5; $i++) {
                        $idNumber = (string) (20250000 + $personId);
                        $email = $emails[$emailIndex % count($emails)];

                        DB::table('people')->insert([
                            'person_id' => $personId,
                            'full_name' => "Student {$personId} - {$course}",
                            'gender' => 'male',
                            'birth_date' => '2003-01-01',
                            'contact_number' => '09123456789',
                            'address' => 'Student Dorm, CPAC',
                            'email' => $email,
                        ]);

                        DB::table('student')->insert([
                            'id_number' => $idNumber,
                            'person_id' => $personId,
                            'year_level' => random_int(1, 4),
                            'course_or_strand' => $course,
                            'department' => $department,
                        ]);

                        DB::table('users')->insert([
                            'person_id' => $personId,
                            'id_number' => $idNumber,
                            'email' => $email,
                            'role' => 'voter',
                        ]);

                        DB::table('user_otps')->insert([
                            'id_number' => $idNumber,
                            'otp_code' => '123456',
                            'otp_expiry' => now()->addMinutes(10),
                        ]);

                        $studentsByDeptCourse[$department][$course][] = [
                            'person_id' => $personId,
                            'id_number' => $idNumber,
                            'name' => "Student {$personId} - {$course}",
                            'course_or_strand' => $course,
                            'department' => $department,
                        ];

                        $personId++;
                        $emailIndex++;
                    }
                }
            }
        }

        // Flatten all students for fallback
        $allStudents = collect($studentsByDeptCourse)->flatten(2);

        // -------------------------------
        // FACULTY
        // -------------------------------
        foreach (array_keys($departments) as $department) {
            $positions = ($department === 'Student Services Office')
                ? ['Department Head', 'Staff', 'Staff']
                : ['Dean', 'Professor', 'Staff'];

            foreach ($positions as $position) {
                $facId = 'FAC2025' . str_pad($personId, 3, '0', STR_PAD_LEFT);
                $email = $emails[$emailIndex % count($emails)];

                DB::table('people')->insert([
                    'person_id' => $personId,
                    'full_name' => "{$position} - {$department}",
                    'gender' => 'male',
                    'birth_date' => '1980-01-01',
                    'contact_number' => '09987654321',
                    'address' => 'Faculty Housing, CPAC',
                    'email' => $email,
                ]);

                DB::table('faculty')->insert([
                    'id_number' => $facId,
                    'person_id' => $personId,
                    'department' => $department,
                    'position' => $position,
                ]);

                DB::table('users')->insert([
                    'person_id' => $personId,
                    'id_number' => $facId,
                    'email' => $email,
                    'role' => 'ComElec',
                ]);

                $personId++;
                $emailIndex++;
            }
        }

        // -------------------------------
        // SAMPLE ELECTIONS WITH VOTES
        // -------------------------------
        $positions = [
            ['President', 3],
            ['Vice President - Religious', 3],
            ['Vice President - Social', 3],
            ['Secretary', 5],
            ['Assistant Secretary', 5],
            ['Treasurer', 5],
            ['Assistant Treasurer', 5],
            ['Auditor', 5],
            ['PIO', 5],
            ['Property Custodian', 5],
            ['Artist', 5],
        ];

        $elections = [
            ['title' => '2024 CPAC USC Election', 'department' => 'General', 'offsetDays' => -30],
            ['title' => '2023 CPAC Theology Election', 'department' => 'Theology', 'offsetDays' => -90],
            ['title' => '2024 CPAC Nursing Election', 'department' => 'Nursing', 'offsetDays' => -60],
        ];

        foreach ($elections as $election) {
            $electionId = DB::table('elections')->insertGetId([
                'title' => $election['title'],
                'start_time' => now()->addDays($election['offsetDays'] - 3),
                'end_time' => now()->addDays($election['offsetDays']),
                'department' => $election['department'],
                'positions' => json_encode(array_column($positions, 0)),
            ]);

            foreach ($positions as [$position, $count]) {
                $deptCourses = $studentsByDeptCourse[$election['department']] ?? [];
                $flatStudents = collect($deptCourses)->flatten(1);

                // Fallback to all students if none in dept
                if ($flatStudents->isEmpty()) {
                    $flatStudents = $allStudents;
                }

                $flatStudents = $flatStudents->shuffle()->take($count);

                foreach ($flatStudents as $student) {
                    $candidateId = DB::table('candidates')->insertGetId([
                        'election_id' => $electionId,
                        'id_number' => $student['id_number'],
                        'name' => $student['name'],
                        'position' => $position,
                        'partylist' => 'Unity Party',
                        'photo' => null,
                    ]);

                    // Insert votes
                    $voterCandidates = $deptCourses ? collect($deptCourses)->flatten(1) : $allStudents;
                    for ($v = 0; $v < random_int(10, 100); $v++) {
                        $voter = $voterCandidates->random();
                        DB::table('votes')->insert([
                            'hashed_id' => Str::random(64),
                            'election_id' => $electionId,
                            'candidate_id' => $candidateId,
                            'position' => $position,
                            'course_or_strand' => $voter['course_or_strand'],
                            'department' => $voter['department'],
                        ]);
                    }
                }
            }
        }
    }
}
