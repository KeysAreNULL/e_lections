<footer class="bg-opacity-80 bg-black text-white text-center p-4 border-t border-gray-700">
    &copy; {{ date('Y') }} CPAC E-lections. All rights reserved.
</footer>
