<footer class="bg-opacity-80 bg-black text-white text-center p-4 border-t border-gray-700">
    &copy; <?php echo e(date('Y')); ?> CPAC E-lections. All rights reserved.
</footer>
<?php /**PATH C:\xampp\htdocs\test_app\resources\views/partials/footer.blade.php ENDPATH**/ ?>