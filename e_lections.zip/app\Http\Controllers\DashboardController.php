<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Models\Election;

class DashboardController extends Controller
{
    public function index()
    {
        $now = now();

        // ✅ Detect ongoing elections using timestamps
        $ongoingElections = Election::where('start_time', '<=', $now)
            ->where('end_time', '>=', $now)
            ->orderByDesc('start_time')
            ->get();

        $ongoingData = [];

        // Precompute student counts per department
        $studentsPerDept = DB::table('student')
            ->select('department', DB::raw('COUNT(*) as total_students'))
            ->groupBy('department')
            ->pluck('total_students', 'department')
            ->toArray();

        foreach ($ongoingElections as $election) {
            $electionId = $election->election_id;

            // Total eligible voters
            $eligibleQuery = DB::table('users')
                ->where('role', 'voter')
                ->join('student', 'users.id_number', '=', 'student.id_number');

            if (!empty($election->department) && strtolower($election->department) !== 'general') {
                $eligibleQuery->where('student.department', $election->department);
            }

            $totalEligible = (int) $eligibleQuery->count();

            // Total distinct voters in this election
            $voted = DB::table('votes')
                ->where('election_id', $electionId)
                ->distinct('hashed_id')
                ->count('hashed_id');

            $notVoted = max(0, $totalEligible - $voted);

            // Normalize positions array
            $positionsRaw = is_array($election->positions)
                ? $election->positions
                : (is_string($election->positions) ? json_decode($election->positions, true) ?? [] : []);
            $positions = [];
            foreach ($positionsRaw as $p) {
                if (is_string($p)) {
                    $positions[] = ['name' => $p, 'max_winners' => 1];
                } elseif (is_array($p)) {
                    $positions[] = ['name' => $p['name'] ?? '', 'max_winners' => (int)($p['max_winners'] ?? 1)];
                } else {
                    $positions[] = ['name' => $p->name ?? '', 'max_winners' => (int)($p->max_winners ?? 1)];
                }
            }

            $results = [];
            $chartsData = [];

            foreach ($positions as $posConfig) {
                $positionName = $posConfig['name'];

                $votes = DB::table('votes')
                    ->join('candidates', 'votes.candidate_id', '=', 'candidates.candidate_id')
                    ->where('votes.election_id', $electionId)
                    ->where('candidates.position', $positionName)
                    ->select('candidates.name', 'votes.department', DB::raw('COUNT(*) as total_votes'))
                    ->groupBy('candidates.name', 'votes.department')
                    ->get();

                if ($votes->isEmpty()) {
                    $results[$positionName] = ['winners' => [], 'total_votes' => 0];
                    $chartsData[$positionName] = $this->emptyCharts();
                    continue;
                }

                $candidateTotals = $votes
                    ->groupBy('name')
                    ->map(fn($v) => $v->sum('total_votes'))
                    ->sortDesc();

                $maxVotes = $candidateTotals->max();
                $maxWinners = $posConfig['max_winners'];

                if ($maxWinners <= 1) {
                    $winners = $candidateTotals
                        ->filter(fn($v) => $v == $maxVotes)
                        ->keys()
                        ->toArray();
                } else {
                    $sorted = $candidateTotals;
                    $winners = [];
                    $taken = 0;
                    foreach ($sorted as $cand => $count) {
                        if ($taken < $maxWinners) {
                            $winners[] = $cand;
                            $taken++;
                        } else {
                            $lastCount = $candidateTotals->values()->slice($maxWinners - 1, 1)->first() ?? null;
                            if ($lastCount !== null && $count == $lastCount) {
                                $winners[] = $cand;
                            } else {
                                break;
                            }
                        }
                    }
                }

                $results[$positionName] = ['winners' => $winners, 'total_votes' => $maxVotes];

                $candidates = $candidateTotals->keys()->toArray();
                $departments = $votes->pluck('department')->unique()->toArray();

                $stackedDatasets = [];
                foreach ($departments as $dept) {
                    $data = [];
                    foreach ($candidates as $candidateName) {
                        $voteRow = $votes->firstWhere(fn($v) => $v->name == $candidateName && $v->department == $dept);
                        $data[] = $voteRow->total_votes ?? 0;
                    }
                    $stackedDatasets[] = [
                        'label' => $dept,
                        'data' => $data,
                        'backgroundColor' => '#' . substr(md5($dept), 0, 6),
                    ];
                }

                $votesPieData = [];
                $votesPieColors = [];
                foreach ($departments as $dept) {
                    $votesPieData[] = $votes->where('department', $dept)->sum('total_votes');
                    $votesPieColors[] = '#' . substr(md5($dept . 'votes'), 0, 6);
                }

                $nonVotersLabels = array_keys($studentsPerDept);
                $nonVotersData = [];
                $nonVotersColors = [];
                foreach ($studentsPerDept as $dept => $totalStudents) {
                    $votedDept = $votes->where('department', $dept)->sum('total_votes');
                    $nonVotersData[] = max(0, $totalStudents - $votedDept);
                    $nonVotersColors[] = '#' . substr(md5($dept . 'novote'), 0, 6);
                }

                if (array_sum($nonVotersData) === 0) {
                    $nonVotersLabels = ['No Non-voters'];
                    $nonVotersData = [1];
                    $nonVotersColors = ['#FFFFFF'];
                }

                // Add all charts for General elections
                if (strtolower($election->department) === 'general') {
                    $chartsData[$positionName] = [
                        'stacked' => ['labels' => $candidates, 'datasets' => $stackedDatasets],
                        'votesPie' => ['labels' => $departments, 'datasets' => [['label' => 'Votes', 'data' => $votesPieData, 'backgroundColor' => $votesPieColors]]],
                        'nonVotersPie' => ['labels' => $nonVotersLabels, 'datasets' => [['label' => 'Non-voters', 'data' => $nonVotersData, 'backgroundColor' => $nonVotersColors]]],
                    ];
                } else {
                    // Add single pie chart for department-only elections
                    $chartsData[$positionName] = [
                        'stacked' => ['labels' => $candidates, 'datasets' => $stackedDatasets],
                        'deptTurnoutPie' => [
                            'labels' => ['Voted', 'Not Voted'],
                            'datasets' => [[
                                'label' => 'Turnout',
                                'data' => [$voted, $notVoted],
                                'backgroundColor' => ['#00FF00', '#FF0000'],
                            ]]
                        ],
                    ];
                }
            }

            $ongoingData[] = [
                'election' => $election,
                'totalEligible' => $totalEligible,
                'voted' => $voted,
                'notVoted' => $notVoted,
                'positions' => array_map(fn($p) => $p['name'], $positions),
                'positionsConfig' => $positions,
                'results' => $results,
                'chartsData' => $chartsData,
            ];
        }

        return view('dashboard', compact('ongoingData'));
    }

    private function emptyCharts()
    {
        return [
            'stacked' => [
                'labels' => ['No Candidates'],
                'datasets' => [['label' => 'Votes', 'data' => [1], 'backgroundColor' => ['#FFFFFF']]]
            ],
            'votesPie' => [
                'labels' => ['No Votes'],
                'datasets' => [['label' => 'Votes', 'data' => [1], 'backgroundColor' => ['#FFFFFF']]]
            ],
            'nonVotersPie' => [
                'labels' => ['No Non-voters'],
                'datasets' => [['label' => 'Non-voters', 'data' => [1], 'backgroundColor' => ['#FFFFFF']]]
            ]
        ];
    }
}
