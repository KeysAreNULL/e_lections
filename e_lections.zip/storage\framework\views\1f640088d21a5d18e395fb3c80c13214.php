<header class="bg-blue-800 shadow-lg text-white p-4 flex justify-between items-center fixed top-0 left-0 w-full z-40">

    <!-- Left Side: Logo + Burger Menu -->
    <div class="flex items-center space-x-4">

        <button id="sidebarToggle" class="md:hidden focus:outline-none">
            <!-- Hamburger Icon -->
            <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
        </button>

        <!-- Logo PNG -->
        <img src="/videos/logo.png" alt="CPAC E-lections Logo" class="h-10 w-auto select-none">
    </div>

</header>
<?php /**PATH C:\xampp\htdocs\test_app\resources\views/partials/header.blade.php ENDPATH**/ ?>