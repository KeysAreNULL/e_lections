

<?php $__env->startSection('title', 'Election Results'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="section-block">
            <h3 class="text-yellow-400 text-2xl font-bold mb-4">Election Results</h3>

            <?php if($elections->isEmpty()): ?>
                <p class="text-gray-400">No finished elections found.</p>
            <?php else: ?>
                <div class="space-y-4">
                    <?php $__currentLoopData = $elections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $election): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="p-4 bg-gray-800 rounded-md flex justify-between items-center">
                            <div>
                                <h4 class="text-lg font-semibold text-white"><?php echo e($election->title); ?></h4>
                                <p class="text-sm text-gray-400">
                                    Ended: <?php echo e(\Carbon\Carbon::parse($election->end_time)->format('M d, Y h:i A')); ?>

                                </p>
                            </div>

                            <div>
                                <?php
                                    $canValidate = in_array(session('role'), ['Comelec Head']);
                                ?>

                                <?php if($canValidate): ?>
                                    <a href="<?php echo e(route('view.result', ['election_id' => $election->election_id])); ?>"
                                        class="btn btn-warning">View Analytics</a>
                                <?php elseif($election->is_validated): ?>
                                    <a href="<?php echo e(route('view.result', ['election_id' => $election->election_id])); ?>"
                                        class="btn btn-warning">View Analytics</a>
                                <?php else: ?>
                                    <span class="text-sm text-gray-500 italic">
                                        Results hidden / Access denied
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- 🔥 Pagination -->
                <div class="mt-6">
                    <?php echo e($elections->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\test_app\resources\views/results/index.blade.php ENDPATH**/ ?>