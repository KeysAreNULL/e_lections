<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\CandidateController;
use App\Http\Controllers\ElectionController;
use App\Http\Controllers\ResultController;
use App\Http\Controllers\VotingController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ResultViewController;



Route::get('/', function () {
    return view('welcome');
});


Route::get('/test', function () {
    return view('test');
});

// 📊 Public results
Route::get('/results', [ResultController::class, 'index'])->name('results');
Route::get('/results/view/{election_id}', [ResultViewController::class, 'view'])->name('view.result');
Route::post('/elections/{id}/validate', [ResultViewController::class, 'validateElection'])->name('elections.validate');


Route::get('/students/search', [CandidateController::class, 'searchStudents'])->name('students.search');



// 🔐 Authentication
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/send-otp', [AuthController::class, 'sendOtp'])->name('send.otp');
Route::post('/verify-otp', [AuthController::class, 'verifyOtp'])->name('verify.otp');
Route::get('/logout', [AuthController::class, 'logout'])->name('logout');

// 🧭 Admin & Comelec Head routes
Route::middleware(['role:admin,Comelec Head'])->group(function () {

    // 🧮 Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // 🗳 Election Management
    Route::get('/elections', [ElectionController::class, 'index'])->name('elections.index');
    Route::post('/elections', [ElectionController::class, 'store'])->name('schedule.election.store');
    Route::put('/elections/{id}', [ElectionController::class, 'update'])->name('elections.update');
    Route::delete('/elections/{id}', [ElectionController::class, 'destroy'])->name('elections.destroy');

    // 👥 Candidate Management
    Route::get('/manage-candidates', [CandidateController::class, 'index'])->name('candidates');
    Route::post('/manage-candidates', [CandidateController::class, 'store'])->name('candidates.store');

    // ✅ Matches Blade forms
    Route::post('/candidates/add/{election_id}', [CandidateController::class, 'store'])->name('candidates.add');
    Route::delete('/candidates/{id}', [CandidateController::class, 'destroy'])->name('candidates.remove');
    Route::put('/candidates/{id}', [CandidateController::class, 'update'])->name('candidates.update');
});

// 🧑‍💻 Voter-only routes
Route::middleware(['role:voter'])->group(function () {
    Route::get('/voting', [VotingController::class, 'show'])->name('voting.window');
    Route::post('/voting/select', [VotingController::class, 'select'])->name('voting.select');
    Route::post('/voting/submit', [VotingController::class, 'submit'])->name('voting.submit');
});
