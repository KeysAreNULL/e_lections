@extends('layouts.app')

@section('title', 'Test Page')

@section('content')
    <h1>This is a test page</h1>
    <p>If you're seeing this with the header, sidebar, and footer — layout works!</p>

    <div class="mt-6 space-x-2">
        <button class="btn btn-save">Save</button>
        <button class="btn btn-danger">Delete</button>
        <button class="btn btn-warning">Other</button>
    </div>
@endsection
