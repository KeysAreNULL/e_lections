<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;

class ResultController extends Controller
{
    public function index()
    {
        // Fetch only elections that have fully ended
        $elections = DB::table('elections')
            ->whereNotNull('start_time')
            ->whereNotNull('end_time')
            ->where('start_time', '<=', now())
            ->where('end_time', '<=', now())
            ->orderBy('end_time', 'desc')
            ->paginate(4); // 🔥 Pagination added

        return view('results.index', compact('elections'));
    }
}
