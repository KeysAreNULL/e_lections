@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
    <div class="container mx-auto p-4">
        <div class="section-block">
            <h3 class="text-yellow-400 text-2xl font-bold mb-2">Welcome, Commissioner</h3>
            <p>This is your dashboard. Analytics appear below for currently ongoing elections.</p>
            <p>Data is semi-live — this page reloads automatically every 15 minutes.</p>

            @if (count($ongoingData) === 0)
                <div class="flex items-center justify-center bg-zinc-800/60 border border-zinc-700 rounded-lg p-6 h-32 mt-4">
                    <p class="italic text-gray-400 text-sm">No active elections right now.</p>
                </div>
            @endif

            @foreach ($ongoingData as $data)
                @php
                    $election = $data['election'];
                    $positions = $data['positions'];
                    $positionsConfig = $data['positionsConfig'];
                    $results = $data['results'];
                    $chartsData = $data['chartsData'];
                @endphp

                <div class="section-block mb-8 border border-gray-700 rounded-lg p-4">
                    <div class="flex justify-between items-start mb-4">
                        <div>
                            <h4 class="text-lg font-semibold text-white">{{ $election->title }}</h4>
                            <p class="text-gray-400 text-sm">
                                {{ ucfirst($election->department) }} —
                                {{ \Carbon\Carbon::parse($election->start_time)->format('M d, Y h:i A') }}
                                to {{ \Carbon\Carbon::parse($election->end_time)->format('M d, Y h:i A') }}
                            </p>
                            <p class="text-sm mt-1 text-gray-300">
                                Eligible: {{ $data['totalEligible'] }} • Voted: {{ $data['voted'] }} • Not Voted:
                                {{ $data['notVoted'] }}
                            </p>
                        </div>

                        <div>
                            <span class="text-green-400 font-semibold">Live</span>
                        </div>
                    </div>

                    {{-- Winners Table --}}
                    <div class="mb-6 overflow-x-auto">
                        <h5 class="text-white font-semibold mb-2">Current Candidates In The Lead</h5>
                        <table class="w-full text-left border-collapse">
                            <thead>
                                <tr class="border-b border-gray-600">
                                    <th class="px-4 py-2 text-white">Position</th>
                                    <th class="px-4 py-2 text-white">Leading</th>
                                    <th class="px-4 py-2 text-white">Votes</th>
                                    <th class="px-4 py-2 text-white">Max Winners</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($positionsConfig as $posConf)
                                    @php
                                        $pname = $posConf['name'];
                                        $maxW = $posConf['max_winners'];
                                        $r = $results[$pname] ?? ['winners' => [], 'total_votes' => 0];
                                    @endphp
                                    <tr class="border-b border-gray-600 {{ count($r['winners']) ? '' : 'text-gray-400' }}">
                                        <td class="px-4 py-2 text-white">{{ $pname }}</td>
                                        <td class="px-4 py-2 text-white">
                                            {{ count($r['winners']) ? implode(', ', $r['winners']) : 'No votes yet' }}
                                        </td>
                                        <td class="px-4 py-2 text-white">{{ $r['total_votes'] }}</td>
                                        <td class="px-4 py-2 text-white">{{ $maxW }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                    {{-- Charts --}}
                    @foreach ($positions as $position)
                        <div class="mb-8">
                            <h3 class="text-xl font-semibold mb-4 text-white">{{ $position }}</h3>

                            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                                {{-- Stacked Bar --}}
                                <div class="section-block p-4 rounded shadow flex flex-col" style="min-height: 360px;">
                                    <h4 class="text-lg font-semibold text-white mb-2">Voters Distribution</h4>
                                    <div class="flex-1">
                                        <canvas
                                            id="stacked-{{ \Illuminate\Support\Str::slug($election->election_id . '-' . $position) }}"></canvas>
                                    </div>
                                </div>

                                {{-- If General Election, show department graphs --}}
                                @if (strtolower($election->department) === 'general')
                                    {{-- Votes Pie --}}
                                    <div class="section-block p-4 rounded shadow">
                                        <h4 class="text-lg font-semibold text-white mb-2">Voters Departmental Divide</h4>
                                        <canvas
                                            id="votesPie-{{ \Illuminate\Support\Str::slug($election->election_id . '-' . $position) }}"></canvas>
                                    </div>

                                    {{-- Non-Voters Pie --}}
                                    <div class="section-block p-4 rounded shadow">
                                        <h4 class="text-lg font-semibold text-white mb-2">Non-voters Departmental Divide
                                        </h4>
                                        <canvas
                                            id="nonVotersPie-{{ \Illuminate\Support\Str::slug($election->election_id . '-' . $position) }}"></canvas>
                                    </div>
                                @else
                                    {{-- Single Pie for Department turnout --}}
                                    <div class="section-block p-4 rounded shadow">
                                        <h4 class="text-lg font-semibold text-white mb-2">Department Voter Turnout</h4>
                                        <canvas
                                            id="deptTurnoutPie-{{ \Illuminate\Support\Str::slug($election->election_id . '-' . $position) }}"></canvas>
                                    </div>
                                @endif

                            </div>
                        </div>
                    @endforeach
                </div>
            @endforeach
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Refresh the page every 15 minutes
        setInterval(() => {
            window.location.reload();
        }, 15 * 60 * 1000);

        document.addEventListener('DOMContentLoaded', function() {
            const whiteOptions = {
                color: '#FFFFFF',
                ticks: {
                    color: '#FFFFFF'
                },
                grid: {
                    color: 'rgba(255,255,255,0.2)'
                }
            };

            @foreach ($ongoingData as $data)
                @php
                    $election = $data['election'];
                    $chartsData = $data['chartsData'];
                @endphp

                @foreach ($chartsData as $position => $charts)
                    // Stacked Bar
                    new Chart(document.getElementById(
                        'stacked-{{ \Illuminate\Support\Str::slug($election->election_id . '-' . $position) }}'
                    ).getContext('2d'), {
                        type: 'bar',
                        data: @json($charts['stacked']),
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                legend: {
                                    labels: {
                                        color: '#FFFFFF',
                                        font: {
                                            size: 10
                                        }
                                    },
                                    position: 'bottom'
                                }
                            },
                            scales: {
                                x: {
                                    ...whiteOptions,
                                    stacked: true
                                },
                                y: {
                                    ...whiteOptions,
                                    stacked: true,
                                    beginAtZero: true
                                }
                            }
                        }
                    });

                    @if (strtolower($election->department) === 'general')
                        // Votes Pie
                        new Chart(document.getElementById(
                            'votesPie-{{ \Illuminate\Support\Str::slug($election->election_id . '-' . $position) }}'
                        ).getContext('2d'), {
                            type: 'pie',
                            data: @json($charts['votesPie']),
                            options: {
                                responsive: true,
                                maintainAspectRatio: true,
                                plugins: {
                                    legend: {
                                        labels: {
                                            color: '#FFFFFF'
                                        },
                                        position: 'bottom'
                                    }
                                }
                            }
                        });

                        // Non-Voters Pie
                        new Chart(document.getElementById(
                            'nonVotersPie-{{ \Illuminate\Support\Str::slug($election->election_id . '-' . $position) }}'
                        ).getContext('2d'), {
                            type: 'pie',
                            data: @json($charts['nonVotersPie']),
                            options: {
                                responsive: true,
                                maintainAspectRatio: true,
                                plugins: {
                                    legend: {
                                        labels: {
                                            color: '#FFFFFF'
                                        },
                                        position: 'bottom'
                                    }
                                }
                            }
                        });
                    @else
                        // Department Turnout Pie
                        @if (isset($charts['deptTurnoutPie']))
                            // Dept Turnout Pie
                            new Chart(document.getElementById(
                                'deptTurnoutPie-{{ \Illuminate\Support\Str::slug($election->election_id . '-' . $position) }}'
                            ).getContext('2d'), {
                                type: 'pie',
                                data: @json($charts['deptTurnoutPie']),
                                options: {
                                    responsive: true,
                                    maintainAspectRatio: true,
                                    plugins: {
                                        legend: {
                                            labels: {
                                                color: '#FFFFFF'
                                            },
                                            position: 'bottom'
                                        }
                                    }
                                }
                            });
                        @endif
                    @endif
                @endforeach
            @endforeach
        });
    </script>
@endsection
