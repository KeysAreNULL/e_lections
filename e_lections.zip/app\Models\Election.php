<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Support\Carbon;

class Election extends Model
{
    use HasFactory;

    protected $table = 'elections';
    public $timestamps = false;

    protected $primaryKey = 'election_id';
    public $incrementing = true;
    protected $keyType = 'int';

    protected $fillable = [
        'title',
        'start_time',
        'end_time',
        'status',
        'department',
        'positions',
        'max_winners', // added
    ];

    protected $casts = [
        'positions' => 'array',
        'max_winners' => 'array', // added
        'start_time' => 'datetime',
        'end_time' => 'datetime',
    ];

    public function candidates()
    {
        return $this->hasMany(Candidate::class, 'election_id', 'election_id')
            ->orderBy('partylist', 'asc'); // <-- sorts alphabetically by partylist
    }


    // Returns true if now >= start_time
    public function hasStarted(): bool
    {
        if (!$this->start_time) {
            return false;
        }
        return Carbon::now()->greaterThanOrEqualTo($this->start_time);
    }

    // Returns true if now >= end_time
    public function hasEnded(): bool
    {
        if (!$this->end_time) {
            return false;
        }
        return Carbon::now()->greaterThanOrEqualTo($this->end_time);
    }

    // Active means started AND not yet ended
    public function isActive(): bool
    {
        return $this->hasStarted() && !$this->hasEnded();
    }

    // Scope to select elections that are active right now (time-based)
    public function scopeActive($query)
    {
        return $query->where('start_time', '<=', now())
            ->where('end_time', '>', now());
    }

    // Scope to select elections that have not yet started
    public function scopeNotStarted($query)
    {
        return $query->where('start_time', '>', now());
    }
}
