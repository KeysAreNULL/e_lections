<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;
use Carbon\Carbon;
use Illuminate\Support\Str;
use App\Jobs\SendOtpEmail;


class AuthController extends Controller
{
    public function showLogin()
    {
        return view('auth.login');
    }

    public function sendOtp(Request $request)
    {
        $id = $request->input('id_number');
        $role = null;

        // Check student
        $user = DB::table('student')
            ->join('people', 'student.person_id', '=', 'people.person_id')
            ->select('student.id_number', 'people.email', 'student.department', 'student.person_id')
            ->where('student.id_number', $id)
            ->first();

        if ($user) {
            $role = 'voter';
        } else {
            // Check faculty
            $user = DB::table('faculty')
                ->join('people', 'faculty.person_id', '=', 'people.person_id')
                ->select('faculty.id_number', 'people.email', 'faculty.department', 'faculty.position', 'faculty.person_id')
                ->where('faculty.id_number', $id)
                ->first();

            if ($user) {
                if ($user->position === 'Dean') {
                    $role = 'admin';
                } elseif ($user->position === 'Department Head' && $user->department === 'Student Services Office') {
                    $role = 'Comelec Head';
                }
            }
        }

        if (!$user || !$role) {
            return back()->with('error', 'ID not found or role not assigned.');
        }

        // Generate OTP
        $otp = rand(100000, 999999);
        $expiry = Carbon::now()->addMinutes(5);

        DB::table('user_otps')->insert([
            'id_number' => $user->id_number,
            'otp_code' => $otp,
            'otp_timestamp' => now(),
            'otp_expiry' => $expiry
        ]);


        // Ensure user exists in `users` table
        DB::table('users')->updateOrInsert(
            ['id_number' => $user->id_number],
            [
                'email' => $user->email,
                'role' => $role === 'Comelec Head' ? 'ComElec' : $role,
                'person_id' => $user->person_id ?? null,
                'created_at' => now(),
                'updated_at' => now(),
            ]
        );

        // Get users.user_id for session
        $userDbId = DB::table('users')->where('id_number', $user->id_number)->value('user_id');

        // Send OTP


        // Dispatch the email job
        SendOtpEmail::dispatch($user->email, $otp);

        // Save session
        session([
            'user_id' => $userDbId,
            'id_number' => $user->id_number,
            'role' => $role,
            'email' => $user->email
        ]);

        request()->session()->put('user_id', $userDbId);
        request()->session()->migrate(true);

        // Record session in database for tracking
        DB::table('sessions')->insert([
            'id' => (string) Str::uuid(),
            'user_id' => $user->id_number,
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent(),
            'payload' => base64_encode(serialize($request->session()->all())),
            'last_activity' => Carbon::now()->timestamp
        ]);

        return back()->with('success', 'OTP sent to your email.');
    }

    public function verifyOtp(Request $request)
    {
        $otp = $request->input('otp_code');
        $id = session('id_number');

        $record = DB::table('user_otps')
            ->where('id_number', $id)
            ->orderByDesc('otp_timestamp')
            ->first();

        if (!$record) {
            return back()->with('error', 'No OTP found.');
        }

        if ($record->otp_code !== $otp) {
            return back()->with('error', 'Incorrect OTP.');
        }

        if (Carbon::now()->greaterThan($record->otp_expiry)) {
            return back()->with('error', 'OTP expired. Please request a new one.');
        }

        // Mark only the used OTP as expired
        DB::table('user_otps')
            ->where('id_number', $id)
            ->where('otp_code', $otp)
            ->update(['otp_expiry' => Carbon::now()->subMinute()]);


        // Update session with users.user_id
        $userDbId = DB::table('users')->where('id_number', $id)->value('user_id');
        request()->session()->put('user_id', $userDbId);
        request()->session()->save();

        $role = session('role');

        if ($role === 'Comelec Head' || $role === 'admin') {
            return redirect()
                ->route('dashboard')
                ->with('success', 'Login successful!')
                ->with('setLoggedIn', true);
        }

        return redirect()
            ->route('voting.window')
            ->with('success', 'Login successful!')
            ->with('setLoggedIn', true);
    }

    public function logout(Request $request)
    {
        $id = session('id_number');

        // Invalidate OTP
        if ($id) {
            DB::table('user_otps')->where('id_number', $id)->update([
                'otp_expiry' => Carbon::now()->subMinute(),
            ]);
        }

        // Remove session values
        Session::flush();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        echo "<script>sessionStorage.removeItem('loggedIn');</script>";

        return redirect()->route('login')->with('success', 'You have been logged out.');
    }
}
