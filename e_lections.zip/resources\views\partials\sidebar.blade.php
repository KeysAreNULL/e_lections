<aside id="sidebar"
    class="w-64 transition-all duration-300 bg-gray-900/90 shadow-2xl p-5
           fixed left-0 top-18 h-[calc(100vh-4rem)] z-30 overflow-y-auto hidden md:block">


    <nav class="space-y-4">
        @php
            $role = session('role'); // pull role from session
        @endphp

        {{-- Comelec Head --}}
        @if ($role === 'Comelec Head')
            <a href="{{ route('dashboard') }}"
                class="block hover:text-yellow-400 {{ request()->routeIs('dashboard') ? 'text-yellow-400 font-bold' : 'text-white' }}">
                Dashboard
            </a>
            <a href="{{ route('elections.index') }}"
                class="block hover:text-yellow-400 {{ request()->routeIs('elections.index') ? 'text-yellow-400 font-bold' : 'text-white' }}">
                Election Manager </a>
            <a href="{{ route('candidates') }}"
                class="block hover:text-yellow-400 {{ request()->routeIs('candidates') ? 'text-yellow-400 font-bold' : 'text-white' }}">
                Candidates
            </a>
            <a href="{{ route('results') }}"
                class="block hover:text-yellow-400 {{ request()->routeIs('results', 'view.result') ? 'text-yellow-400 font-bold' : 'text-white' }}">
                Results
            </a>
            <a href="{{ route('logout') }}" class="block text-white hover:text-yellow-400">Logout</a>

            {{-- Admin --}}
        @elseif ($role === 'admin')
            <a href="{{ route('dashboard') }}"
                class="block hover:text-yellow-400 {{ request()->routeIs('dashboard') ? 'text-yellow-400 font-bold' : 'text-white' }}">
                Dashboard
            </a>
            <a href="{{ route('elections.index') }}"
                class="block hover:text-yellow-400 {{ request()->routeIs('elections.index') ? 'text-yellow-400 font-bold' : 'text-white' }}">
                Election Manager </a>
            <a href="{{ route('candidates') }}"
                class="block hover:text-yellow-400 {{ request()->routeIs('candidates') ? 'text-yellow-400 font-bold' : 'text-white' }}">
                Candidates
            </a>
            <a href="{{ route('results') }}"
                class="block hover:text-yellow-400 {{ request()->routeIs('results', 'view.result') ? 'text-yellow-400 font-bold' : 'text-white' }}">
                Results
            </a>
            <a href="{{ route('logout') }}" class="block text-white hover:text-yellow-400">Logout</a>

            {{-- Voter --}}
        @elseif ($role === 'voter')
            <a href="{{ route('voting.window') }}"
                class="block hover:text-yellow-400 {{ request()->routeIs('voting.window') ? 'text-yellow-400 font-bold' : 'text-white' }}">
                Voting Window
            </a>
            <a href="{{ route('results') }}"
                class="block hover:text-yellow-400 {{ request()->routeIs('results', 'view.result') ? 'text-yellow-400 font-bold' : 'text-white' }}">
                Results
            </a>
            <a href="{{ route('logout') }}" class="block text-white hover:text-yellow-400">Logout</a>
        @endif
    </nav>
</aside>
