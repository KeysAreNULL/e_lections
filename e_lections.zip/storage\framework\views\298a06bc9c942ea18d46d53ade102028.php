<?php $__env->startSection('title', 'Test Page'); ?>

<?php $__env->startSection('content'); ?>
    <h1>This is a test page</h1>
    <p>If you're seeing this with the header, sidebar, and footer — layout works!</p>

    <div class="mt-6 space-x-2">
        <button class="btn btn-save">Save</button>
        <button class="btn btn-danger">Delete</button>
        <button class="btn btn-warning">Other</button>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\test_app\resources\views\test.blade.php ENDPATH**/ ?>