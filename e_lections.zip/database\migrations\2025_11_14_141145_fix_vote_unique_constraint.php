<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::table('votes', function (Blueprint $table) {
            // Drop the old constraint
            $table->dropUnique('uq_vote_once'); // or whatever the index name actually is

            // Add the correct constraint
            $table->unique(['hashed_id', 'election_id', 'position', 'candidate_id'], 'uq_vote_multi');
        });
    }

    public function down()
    {
        Schema::table('votes', function (Blueprint $table) {
            $table->dropUnique('uq_vote_multi');

            // Restore the old one
            $table->unique(['hashed_id', 'election_id'], 'uq_vote_once');
        });
    }

};
