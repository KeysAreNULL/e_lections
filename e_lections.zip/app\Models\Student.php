<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    use HasFactory;

    protected $table = 'student'; // ✅ matches your migration (no "s")
    protected $primaryKey = 'id_number';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'id_number',
        'person_id',
        'year_level',
        'course_or_strand',
        'department',
    ];

    public function person()
    {
        return $this->belongsTo(Person::class, 'person_id', 'person_id');
    }
}
