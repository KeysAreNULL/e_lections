<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Election;
use App\Models\Candidate;
use Carbon\Carbon;

class CandidateController extends Controller
{
    private function facultyDeptForSession(?string $idNumber)
    {
        if (!$idNumber)
            return null;
        return DB::table('faculty')->where('id_number', $idNumber)->value('department');
    }

    private function canManageDepartment(string $dept = null): bool
    {
        $role = session('role');
        $idNumber = session('id_number');
        if ($role === 'Comelec Head')
            return true;
        if ($role === 'admin') {
            $facultyDept = $this->facultyDeptForSession($idNumber);
            return $facultyDept !== null && $facultyDept === $dept;
        }
        return false;
    }

    public function index()
    {
        $role = session('role');
        $idNumber = session('id_number');

        if (!$role || !$idNumber) {
            return redirect()->route('login')->withErrors(['auth' => 'You must be logged in.']);
        }

        $facultyDept = $this->facultyDeptForSession($idNumber);

        $electionQuery = Election::query()
            ->where('end_time', '>', Carbon::now(config('app.timezone')))
            ->orderBy('start_time', 'desc');

        if ($role !== 'Comelec Head') {
            if ($facultyDept) {
                $electionQuery->where('department', $facultyDept);
            } else {
                $electionQuery->whereRaw('0 = 1');
            }
        }

        $elections = $electionQuery->get()->map(function ($election) {
            // Decode positions JSON if it's a string, ensure array
            if (!is_array($election->positions)) {
                $election->positions = $election->positions ? json_decode($election->positions, true) ?? [] : [];
            }
            return $election;
        });

        $candidates = Candidate::with('election')
            ->whereIn('election_id', $elections->pluck('election_id')->toArray())
            ->get();

        // Prepare elections for JS dropdown
        $electionsForJs = $elections->map(function ($election) {
            return [
                'election_id' => $election->election_id,
                'title' => $election->title,
                'department' => $election->department,
                'positions' => $election->positions,
            ];
        });

        return view('manage_candidates', [
            'elections' => $elections,
            'candidates' => $candidates,
            'electionsForJs' => $electionsForJs, // pass to JS
        ]);
    }




    public function store(Request $request)
    {
        $request->validate([
            'election_id' => 'required|exists:elections,election_id',
            'id_number' => 'required|exists:student,id_number',
            'position' => 'required|string|max:50',
            'partylist' => 'required|string|max:50',
            'photo' => 'nullable|image|max:2048',
        ]);

        $election = Election::findOrFail($request->election_id);

        if (!$this->canManageDepartment($election->department)) {
            return back()->withErrors(['error' => 'You cannot add candidates to elections outside your department.']);
        }

        if ($election->hasStarted()) {
            return back()->withErrors(['error' => 'Cannot add candidate to an active or ended election.']);
        }

        // 🔍 Fetch name based on `id_number`
        $student = DB::table('student')
            ->join('people', 'student.person_id', '=', 'people.person_id')
            ->where('student.id_number', $request->id_number)
            ->select('people.full_name')
            ->first();

        if (!$student) {
            return back()->withErrors(['error' => 'Student not found in records.']);
        }

        $photoData = $request->file('photo') ? file_get_contents($request->file('photo')->getRealPath()) : null;

        Candidate::create([
            'election_id' => $request->election_id,
            'id_number' => $request->id_number,
            'name' => $student->full_name,
            'position' => $request->position,
            'partylist' => $request->partylist,
            'photo' => $photoData,
        ]);

        return redirect()->route('candidates')->with('success', 'Candidate added successfully!');
    }

    public function update(Request $request, $id)
    {
        $candidate = Candidate::findOrFail($id);

        $request->validate([
            'partylist' => 'nullable|string|max:255',
            'position' => 'required|string|max:255',
            'photo' => 'nullable|image|max:2048',
        ]);

        $candidate->partylist = $request->partylist;
        $candidate->position = $request->position;

        if ($request->hasFile('photo')) {
            $candidate->photo = file_get_contents($request->file('photo')->getRealPath());
        }

        $candidate->save();

        return redirect()->route('elections.index')->with('success', 'Candidate updated successfully!');
    }

    public function destroy($id)
    {
        $candidate = Candidate::findOrFail($id);
        $election = $candidate->election;

        if (!$this->canManageDepartment($election->department)) {
            return back()->withErrors(['error' => 'You cannot delete candidates outside your department.']);
        }

        if ($candidate->election && $candidate->election->hasStarted()) {
            return back()->withErrors(['error' => 'Cannot remove candidate from an active election.']);
        }

        $candidate->delete();

        return back()->with('success', 'Candidate removed successfully.');
    }

    // AJAX student search with department filter
    public function searchStudents(Request $request)
    {
        $query = $request->get('query', '');
        $department = $request->get('department', null);

        $students = DB::table('student')
            ->join('people', 'student.person_id', '=', 'people.person_id')
            ->when($department && strtolower($department) !== 'general', function ($q) use ($department) {
                $q->where('student.department', $department);
            })
            ->where('people.full_name', 'LIKE', "%{$query}%")
            ->select('student.id_number', 'people.full_name')
            ->limit(10)
            ->get();

        return response()->json($students);
    }
}

?>