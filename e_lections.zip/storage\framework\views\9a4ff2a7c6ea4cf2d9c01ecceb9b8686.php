

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto p-4">
        <div class="section-block">
            <h3 class="text-yellow-400 text-2xl font-bold mb-2">Welcome, Commissioner</h3>
            <p>This is your dashboard. Analytics appear below for currently ongoing elections.</p>
            <p>Data is semi-live — this page reloads automatically every 15 minutes.</p>

            <?php if(count($ongoingData) === 0): ?>
                <div class="flex items-center justify-center bg-zinc-800/60 border border-zinc-700 rounded-lg p-6 h-32 mt-4">
                    <p class="italic text-gray-400 text-sm">No active elections right now.</p>
                </div>
            <?php endif; ?>

            <?php $__currentLoopData = $ongoingData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $election = $data['election'];
                    $positions = $data['positions'];
                    $positionsConfig = $data['positionsConfig'];
                    $results = $data['results'];
                    $chartsData = $data['chartsData'];
                ?>

                <div class="section-block mb-8 border border-gray-700 rounded-lg p-4">
                    <div class="flex justify-between items-start mb-4">
                        <div>
                            <h4 class="text-lg font-semibold text-white"><?php echo e($election->title); ?></h4>
                            <p class="text-gray-400 text-sm">
                                <?php echo e(ucfirst($election->department)); ?> —
                                <?php echo e(\Carbon\Carbon::parse($election->start_time)->format('M d, Y h:i A')); ?>

                                to <?php echo e(\Carbon\Carbon::parse($election->end_time)->format('M d, Y h:i A')); ?>

                            </p>
                            <p class="text-sm mt-1 text-gray-300">
                                Eligible: <?php echo e($data['totalEligible']); ?> • Voted: <?php echo e($data['voted']); ?> • Not Voted:
                                <?php echo e($data['notVoted']); ?>

                            </p>
                        </div>

                        <div>
                            <span class="text-green-400 font-semibold">Live</span>
                        </div>
                    </div>

                    
                    <div class="mb-6 overflow-x-auto">
                        <h5 class="text-white font-semibold mb-2">Current Candidates In The Lead</h5>
                        <table class="w-full text-left border-collapse">
                            <thead>
                                <tr class="border-b border-gray-600">
                                    <th class="px-4 py-2 text-white">Position</th>
                                    <th class="px-4 py-2 text-white">Leading</th>
                                    <th class="px-4 py-2 text-white">Votes</th>
                                    <th class="px-4 py-2 text-white">Max Winners</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $positionsConfig; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posConf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $pname = $posConf['name'];
                                        $maxW = $posConf['max_winners'];
                                        $r = $results[$pname] ?? ['winners' => [], 'total_votes' => 0];
                                    ?>
                                    <tr class="border-b border-gray-600 <?php echo e(count($r['winners']) ? '' : 'text-gray-400'); ?>">
                                        <td class="px-4 py-2 text-white"><?php echo e($pname); ?></td>
                                        <td class="px-4 py-2 text-white">
                                            <?php echo e(count($r['winners']) ? implode(', ', $r['winners']) : 'No votes yet'); ?>

                                        </td>
                                        <td class="px-4 py-2 text-white"><?php echo e($r['total_votes']); ?></td>
                                        <td class="px-4 py-2 text-white"><?php echo e($maxW); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    
                    <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-8">
                            <h3 class="text-xl font-semibold mb-4 text-white"><?php echo e($position); ?></h3>

                            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                                
                                <div class="section-block p-4 rounded shadow flex flex-col" style="min-height: 360px;">
                                    <h4 class="text-lg font-semibold text-white mb-2">Voters Distribution</h4>
                                    <div class="flex-1">
                                        <canvas
                                            id="stacked-<?php echo e(\Illuminate\Support\Str::slug($election->election_id . '-' . $position)); ?>"></canvas>
                                    </div>
                                </div>

                                
                                <?php if(strtolower($election->department) === 'general'): ?>
                                    
                                    <div class="section-block p-4 rounded shadow">
                                        <h4 class="text-lg font-semibold text-white mb-2">Voters Departmental Divide</h4>
                                        <canvas
                                            id="votesPie-<?php echo e(\Illuminate\Support\Str::slug($election->election_id . '-' . $position)); ?>"></canvas>
                                    </div>

                                    
                                    <div class="section-block p-4 rounded shadow">
                                        <h4 class="text-lg font-semibold text-white mb-2">Non-voters Departmental Divide
                                        </h4>
                                        <canvas
                                            id="nonVotersPie-<?php echo e(\Illuminate\Support\Str::slug($election->election_id . '-' . $position)); ?>"></canvas>
                                    </div>
                                <?php else: ?>
                                    
                                    <div class="section-block p-4 rounded shadow">
                                        <h4 class="text-lg font-semibold text-white mb-2">Department Voter Turnout</h4>
                                        <canvas
                                            id="deptTurnoutPie-<?php echo e(\Illuminate\Support\Str::slug($election->election_id . '-' . $position)); ?>"></canvas>
                                    </div>
                                <?php endif; ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Refresh the page every 15 minutes
        setInterval(() => {
            window.location.reload();
        }, 15 * 60 * 1000);

        document.addEventListener('DOMContentLoaded', function() {
            const whiteOptions = {
                color: '#FFFFFF',
                ticks: {
                    color: '#FFFFFF'
                },
                grid: {
                    color: 'rgba(255,255,255,0.2)'
                }
            };

            <?php $__currentLoopData = $ongoingData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $election = $data['election'];
                    $chartsData = $data['chartsData'];
                ?>

                <?php $__currentLoopData = $chartsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position => $charts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    // Stacked Bar
                    new Chart(document.getElementById(
                        'stacked-<?php echo e(\Illuminate\Support\Str::slug($election->election_id . '-' . $position)); ?>'
                    ).getContext('2d'), {
                        type: 'bar',
                        data: <?php echo json_encode($charts['stacked'], 15, 512) ?>,
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                legend: {
                                    labels: {
                                        color: '#FFFFFF',
                                        font: {
                                            size: 10
                                        }
                                    },
                                    position: 'bottom'
                                }
                            },
                            scales: {
                                x: {
                                    ...whiteOptions,
                                    stacked: true
                                },
                                y: {
                                    ...whiteOptions,
                                    stacked: true,
                                    beginAtZero: true
                                }
                            }
                        }
                    });

                    <?php if(strtolower($election->department) === 'general'): ?>
                        // Votes Pie
                        new Chart(document.getElementById(
                            'votesPie-<?php echo e(\Illuminate\Support\Str::slug($election->election_id . '-' . $position)); ?>'
                        ).getContext('2d'), {
                            type: 'pie',
                            data: <?php echo json_encode($charts['votesPie'], 15, 512) ?>,
                            options: {
                                responsive: true,
                                maintainAspectRatio: true,
                                plugins: {
                                    legend: {
                                        labels: {
                                            color: '#FFFFFF'
                                        },
                                        position: 'bottom'
                                    }
                                }
                            }
                        });

                        // Non-Voters Pie
                        new Chart(document.getElementById(
                            'nonVotersPie-<?php echo e(\Illuminate\Support\Str::slug($election->election_id . '-' . $position)); ?>'
                        ).getContext('2d'), {
                            type: 'pie',
                            data: <?php echo json_encode($charts['nonVotersPie'], 15, 512) ?>,
                            options: {
                                responsive: true,
                                maintainAspectRatio: true,
                                plugins: {
                                    legend: {
                                        labels: {
                                            color: '#FFFFFF'
                                        },
                                        position: 'bottom'
                                    }
                                }
                            }
                        });
                    <?php else: ?>
                        // Department Turnout Pie
                        <?php if(isset($charts['deptTurnoutPie'])): ?>
                            // Dept Turnout Pie
                            new Chart(document.getElementById(
                                'deptTurnoutPie-<?php echo e(\Illuminate\Support\Str::slug($election->election_id . '-' . $position)); ?>'
                            ).getContext('2d'), {
                                type: 'pie',
                                data: <?php echo json_encode($charts['deptTurnoutPie'], 15, 512) ?>,
                                options: {
                                    responsive: true,
                                    maintainAspectRatio: true,
                                    plugins: {
                                        legend: {
                                            labels: {
                                                color: '#FFFFFF'
                                            },
                                            position: 'bottom'
                                        }
                                    }
                                }
                            });
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\test_app\resources\views\dashboard.blade.php ENDPATH**/ ?>