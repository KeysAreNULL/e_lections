@extends('layouts.app')

@section('title', 'Election Results')

@section('content')
    <div class="container">
        <div class="section-block">
            <h3 class="text-yellow-400 text-2xl font-bold mb-4">Election Results</h3>

            @if ($elections->isEmpty())
                <p class="text-gray-400">No finished elections found.</p>
            @else
                <div class="space-y-4">
                    @foreach ($elections as $election)
                        <div class="p-4 bg-gray-800 rounded-md flex justify-between items-center">
                            <div>
                                <h4 class="text-lg font-semibold text-white">{{ $election->title }}</h4>
                                <p class="text-sm text-gray-400">
                                    Ended: {{ \Carbon\Carbon::parse($election->end_time)->format('M d, Y h:i A') }}
                                </p>
                            </div>

                            <div>
                                @php
                                    $canValidate = in_array(session('role'), ['Comelec Head']);
                                @endphp

                                @if ($canValidate)
                                    <a href="{{ route('view.result', ['election_id' => $election->election_id]) }}"
                                        class="btn btn-warning">View Analytics</a>
                                @elseif ($election->is_validated)
                                    <a href="{{ route('view.result', ['election_id' => $election->election_id]) }}"
                                        class="btn btn-warning">View Analytics</a>
                                @else
                                    <span class="text-sm text-gray-500 italic">
                                        Results hidden / Access denied
                                    </span>
                                @endif
                            </div>
                        </div>
                    @endforeach
                </div>

                <!-- 🔥 Pagination -->
                <div class="mt-6">
                    {{ $elections->links() }}
                </div>
            @endif
        </div>
    </div>
@endsection
