<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Election;

class ResultViewController extends Controller
{
    public function index()
    {
        $elections = Election::orderBy('start_time', 'desc')->get();
        return view('results.index', compact('elections'));
    }

    public function view($election_id)
    {
        $election = Election::with('candidates')->findOrFail($election_id);

        // Block access if election is not validated and user is not Comelec Head
        if (!$election->is_validated && session('role') !== 'Comelec Head') {
            abort(403, 'Access denied. This election has not been validated yet.');
        }

        $positions = is_array($election->positions) ? $election->positions : json_decode($election->positions, true) ?? [];
        $maxWinners = is_array($election->max_winners) ? $election->max_winners : json_decode($election->max_winners, true) ?? [];
        $results = [];
        $chartsData = [];

        $studentsPerDept = DB::table('student')
            ->select('department', DB::raw('COUNT(*) as total_students'))
            ->groupBy('department')
            ->pluck('total_students', 'department')
            ->toArray();

        foreach ($positions as $index => $position) {

            $positionMaxWinners = $maxWinners[$index] ?? 1;

            $votes = DB::table('votes')
                ->join('candidates', 'votes.candidate_id', '=', 'candidates.candidate_id')
                ->where('votes.election_id', $election_id)
                ->where('candidates.position', $position)
                ->select('candidates.name', 'votes.department', DB::raw('COUNT(*) as total_votes'))
                ->groupBy('candidates.name', 'votes.department')
                ->get();

            if ($votes->isEmpty()) {
                $results[$position] = [
                    'winners' => [],
                    'total_votes' => 0,
                    'max_winners' => $positionMaxWinners,
                    'isTie' => false
                ];
                $chartsData[$position] = $this->emptyCharts();
                continue;
            }

            $candidateTotals = $votes->groupBy('name')->map(fn($v) => $v->sum('total_votes'));
            $maxVotes = $candidateTotals->max();

            // ✅ Get all candidates with the top votes (show ties)
            $topCandidates = $candidateTotals->filter(fn($v) => $v == $maxVotes)->keys()->toArray();

            $results[$position] = [
                'winners' => $topCandidates,                     // all top-vote candidates
                'total_votes' => $maxVotes,
                'max_winners' => $positionMaxWinners,
                'validated' => count($topCandidates) <= $positionMaxWinners,
                'isTie' => count($topCandidates) > $positionMaxWinners
            ];

            $candidates = $candidateTotals->keys()->toArray();
            $departments = $votes->pluck('department')->unique()->toArray();

            // Stacked Bar Chart
            $stackedDatasets = [];
            foreach ($departments as $dept) {
                $data = [];
                foreach ($candidates as $candidate) {
                    $vote = $votes->firstWhere(fn($v) => $v->name == $candidate && $v->department == $dept);
                    $data[] = $vote->total_votes ?? 0;
                }
                $stackedDatasets[] = [
                    'label' => $dept,
                    'data' => $data,
                    'backgroundColor' => '#' . substr(md5($dept), 0, 6)
                ];
            }
            $chartsData[$position] = ['stacked' => ['labels' => $candidates, 'datasets' => $stackedDatasets]];

            // Votes Pie / Non-voters Pie
            if ($election->department == 'General') {
                $votesPieData = [];
                $votesPieColors = [];
                foreach ($departments as $dept) {
                    $votesPieData[] = $votes->where('department', $dept)->sum('total_votes');
                    $votesPieColors[] = '#' . substr(md5($dept . 'votes'), 0, 6);
                }
                $chartsData[$position]['votesPie'] = [
                    'labels' => $departments,
                    'datasets' => [['label' => 'Votes', 'data' => $votesPieData, 'backgroundColor' => $votesPieColors]]
                ];

                $nonVotersData = [];
                $nonVotersColors = [];
                foreach ($studentsPerDept as $dept => $totalStudents) {
                    $voted = $votes->where('department', $dept)->sum('total_votes');
                    $nonVotersData[] = max($totalStudents - $voted, 0);
                    $nonVotersColors[] = '#' . substr(md5($dept . 'novote'), 0, 6);
                }
                $chartsData[$position]['nonVotersPie'] = [
                    'labels' => array_keys($studentsPerDept),
                    'datasets' => [['label' => 'Non-voters', 'data' => $nonVotersData, 'backgroundColor' => $nonVotersColors]]
                ];
            } else {
                // Department-specific turnout
                $department = $election->department;
                $totalStudents = $studentsPerDept[$department] ?? 0;
                $totalVoted = $votes->sum('total_votes');
                $nonVoted = max($totalStudents - $totalVoted, 0);

                $chartsData[$position]['deptTurnoutPie'] = [
                    'labels' => ['Voted', 'Did Not Vote'],
                    'datasets' => [
                        [
                            'label' => 'Turnout',
                            'data' => [$totalVoted, $nonVoted],
                            'backgroundColor' => [
                                '#' . substr(md5('voted'), 0, 6),
                                '#' . substr(md5('notvoted'), 0, 6)
                            ]
                        ]
                    ]
                ];
            }
        }

        return view('results.view', compact('election', 'positions', 'results', 'chartsData'));
    }

    public function validateElection($id)
    {
        $election = Election::findOrFail($id);

        if (!in_array(session('role'), ['Comelec Head'])) {
            return back()->withErrors(['error' => 'Unauthorized to validate this election.']);
        }

        $election->is_validated = !$election->is_validated;
        $election->save();

        $message = $election->is_validated
            ? 'Election results are now validated and visible.'
            : 'Election results are now hidden.';

        return redirect()->route('view.result', ['election_id' => $id])->with('success', $message);

    }

    private function emptyCharts()
    {
        return [
            'stacked' => [
                'labels' => ['No Candidates'],
                'datasets' => [['label' => 'Votes', 'data' => [1], 'backgroundColor' => ['#FFFFFF']]]
            ],
            'votesPie' => [
                'labels' => ['No Votes'],
                'datasets' => [['label' => 'Votes', 'data' => [1], 'backgroundColor' => ['#FFFFFF']]]
            ],
            'nonVotersPie' => [
                'labels' => ['No Non-voters'],
                'datasets' => [['label' => 'Non-voters', 'data' => [1], 'backgroundColor' => ['#FFFFFF']]]
            ],
            'deptTurnoutPie' => [
                'labels' => ['No Data'],
                'datasets' => [['label' => 'Turnout', 'data' => [1], 'backgroundColor' => ['#FFFFFF']]]
            ],
        ];
    }
}
