{{-- resources/views/auth/login.blade.php --}}
@extends('layouts.guest')

@section('title', 'Login')

@section('content')
    <div class="container flex justify-center items-center min-h-[70vh]">
        <div class="section-block max-w-md w-full p-8">

            <h2 class="text-2xl font-bold text-yellow-400 text-center mb-6">Login to E-lections</h2>

            {{-- ID Form --}}
            <form method="POST" action="{{ route('send.otp') }}" class="mb-8">
                @csrf
                <input type="text" name="id_number" placeholder="ID Number" class="input w-full mb-4" required>
                <button type="submit" class="btn btn-save w-full">
                    Send OTP
                </button>
            </form>

            {{-- OTP Form --}}
            <form method="POST" action="{{ route('verify.otp') }}">
                @csrf
                <input type="text" name="otp_code" placeholder="6-digit OTP" maxlength="6" class="input w-full mb-4"
                    required>
                <button type="submit" class="w-full py-3 bg-green-600 hover:bg-green-700 rounded font-semibold transition">
                    Login
                </button>
            </form>

            {{-- Messages --}}
            @if (session('error'))
                <p class="text-red-400 mt-4 text-center font-semibold">{{ session('error') }}</p>
            @endif

            @if (session('success'))
                <p class="text-green-400 mt-4 text-center font-semibold">{{ session('success') }}</p>
            @endif

        </div>
    </div>
@endsection
